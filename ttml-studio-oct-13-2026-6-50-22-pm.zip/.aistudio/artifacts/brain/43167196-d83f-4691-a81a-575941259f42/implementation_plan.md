# TTML Studio — Native Android Word-Synchronized Lyric Workstation

TTML Studio is a native Android audio workstation engineered for songwriters, lyricists, and audio engineers to create, align, translate, and export Apple Music-style word-synchronized TTML (`Timed Text Markup Language`) lyrics with millisecond precision.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during the interactive interview:
> - **Primary Workflow**: Full DAW-style audio workstation timeline featuring interactive waveforms, draggable word blocks, edge trimming handles, and an integrated real-time Tap-to-Sync recording mode.
> - **Zero-State Experience**: Starts with an empty project workspace featuring clear onboarding actions (Pick Audio, Import Lyrics, or Search LRCLIB), while preserving an instant "Load Demo Project" option for rapid exploration.
> - **Translation & Transliteration Strategy**: Offline-first phonetic transliteration engine (IPA and romanized scripts including Arabic support) paired with an optional Gemini API cloud translation engine configured via the AI Studio Secrets panel.

---

## 1. Overview & Core Concept

Apple Music word-synchronized lyrics rely on the TTML standard with iTunes namespace extensions (`xmlns:itunes="http://music.apple.com/lyric-ttml"`). Unlike traditional LRC line files, word-synced TTML specifies millisecond-accurate begin and end timestamps for every syllable and word, singer identifiers (`v1`, `v2`, background vocals), and structural role tags.

TTML Studio delivers a native Android tool for this workflow:
- **Audio Workstation Experience**: A multi-lane horizontal timeline with real waveform rendering, millisecond time ruler, smooth scrubbing playhead, magnetic snapping, and edge drag trimming.
- **Real-Time Tap-to-Sync**: Tap rhythmically along with the audio playback to stamp word timings effortlessly on mobile touchscreens.
- **Multi-Singer Architecture**: Assign voices (`V1`, `V2`, `V3`, background vocals, ad-libs) with distinct color coding across the entire timeline and lyric displays.
- **Multilingual Support**: Side-by-side translation and phonetic transliteration views supporting international scripts, including Arabic transliteration and IPA notation.
- **Industrial-Grade TTML Engine**: Robust XML parser and serializer built on Android's `XmlPullParser` ensuring well-formed XML namespaces, escaping, and validation before file export.
- **Offline Reliability & Local Persistence**: Room-backed local storage auto-saving user projects, audio references, and revision history.

---

## 2. User Experience & Visual Design

### Visual Identity & Theme
- **Vibe**: High-precision Dark Audio Workstation (DAW) aesthetic inspired by professional music production software.
- **Color Palette**:
  - Background: Deep Studio Obsidian (`#0D0F14`) and Surface Slate (`#161922`)
  - Accent / Playhead: Electric Cyan (`#00E5FF`) and Vivid Amber (`#FFB300`)
  - Singer Tracks:
    - Voice 1 (Lead): Neon Violet (`#8B5CF6`)
    - Voice 2 (Duet / Harmony): Emerald Cyan (`#10B981`)
    - Voice 3 / Background / Ad-lib: Warm Sunset Rose (`#F43F5E`)
  - Waveform: Translucent Steel Blue (`#2E384D`) with highlighted active regions
- **Typography**: Clean monospace timecode readouts (`00:02.450`) paired with crisp legible sans-serif display typography for lyric text.
- **Touch Ergonomics**: Minimum 48dp interactive touch targets, tactile grab handles on word boundaries, long-press contextual menus, and edge-to-edge system safe area insets.

### Navigation & Top-Level Screens
1. **Import Screen**:
   - Audio Picker (SAF document picker for MP3, WAV, FLAC, M4A, OGG).
   - Lyrics File Picker (.ttml, .lrc, enhanced LRC, .srt, .txt).
   - Direct Paste dialog with automatic line and word segmentation.
   - LRCLIB search modal: Live query by title and artist, result previews with word/line sync badges, and one-tap import into the timeline.
2. **Timeline Screen (Core DAW)**:
   - Header: Master transport controls (Play/Pause, Loop Word/Selection, Return to Zero, Timecode display, Zoom slider, Fit Song button).
   - Time Ruler: Millisecond grid markings, tap-to-seek, and playhead position marker.
   - Waveform Canvas: Amplitude visualization computed from audio file peaks.
   - Word Lanes: Draggable, resizable word chips color-coded by singer. Left/right resize grips for precise boundary trimming.
   - Snap & Precision Controls: Magnetic snap toggle (snaps to adjacent word ends/starts and playhead), ±10ms and ±50ms nudge buttons, manual millisecond editor.
   - Tap-to-Sync Mode: Interactive floating action bar with large tap pad, "Tap Next Word", "Undo Last Tap", and progress tracker.
3. **Translate & Pronunciation Screen**:
   - Split/side-by-side row view displaying Original Word/Line, Target Translation, and Phonetic Pronunciation.
   - Target language selector with offline phonetic rules and optional Gemini AI translation batching.
   - Arabic script support with customizable transliteration styles.
4. **Preview Screen**:
   - Immersive full-screen Apple Music-style lyrics experience.
   - Smooth word-level karaoke fill illumination and non-jarring active line elevation.
   - Duet singer layout with multi-agent vocal lane positioning.
   - Scrubbable bottom progress bar and playback toggles.
5. **Export Screen**:
   - Formatted TTML XML code viewer with line numbers and syntax highlighting.
   - "Copy All TTML" button with instant clipboard confirmation.
   - "Export File" using Android Storage Access Framework (Downloads folder destination).
   - Android Share Sheet integration.
   - Schema validation checker reporting well-formedness and timestamp chronological integrity.

---

## 3. Key Product Decisions & Trade-Offs

### Decision 1: Audio Playback & Waveform Pipeline
- **Chosen Approach**: AndroidX Media3 ExoPlayer combined with a background coroutine waveform extractor that samples audio amplitudes into an indexed float array.
- **Why**: Media3 provides sub-millisecond seek accuracy, reliable background playback, and universal audio container decoding (MP3, AAC, FLAC, OGG, WAV).
- **Alternative Considered**: Android `MediaPlayer` was rejected due to unpredictable seek latency and lack of precise position polling required for word-level sync.

### Decision 2: XML Serialization & Parsing Architecture
- **Chosen Approach**: Built-in Android `XmlPullParser` and `FastXmlSerializer` instead of regex string replacements.
- **Why**: Apple Music TTML specifications strictly require valid XML structure, proper escaping of entities (`&amp;`, `&lt;`), correct namespaces (`xmlns="http://www.w3.org/ns/ttml"`, `xmlns:ttm="http://www.w3.org/ns/ttml#metadata"`, `xmlns:itunes="http://music.apple.com/lyric-ttml"`), and nested `<span>` hierarchies. Regular expressions easily break on multiline attributes or nested tags.

### Decision 3: Touch Precision on Mobile Screens
- **Chosen Approach**: Dual editing controls: visual horizontal drag & pinch-to-zoom on the timeline canvas, complemented by a persistent bottom inspection bar offering ±10ms / ±50ms nudge buttons and numeric input.
- **Why**: Direct finger dragging on a phone screen can obscure small 200ms words. Micro-nudge buttons allow pinpoint accuracy without accidental finger slips.

### Decision 4: Translation Architecture
- **Chosen Approach**: Hybrid offline transliteration dictionary + optional Gemini REST API endpoint via `BuildConfig.GEMINI_API_KEY`.
- **Why**: Ensures core phonetic features work completely offline in airplane mode, while enabling rich context-aware AI translation when connectivity and keys are available.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                 TTML Studio                                 │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
            ┌──────────────────────────┴──────────────────────────┐
            ▼                                                     ▼
┌───────────────────────┐                             ┌───────────────────────┐
│     UI Layer (M3)     │                             │   Audio & Media Layer │
│  - MainWorkstation    │◄──────── Playhead Flow ─────┤  - Media3 ExoPlayer   │
│  - TimelineView       │                             │  - WaveformSampler    │
│  - TapToSyncBar       │                             │  - PositionPoller     │
│  - TranslateView      │                             └───────────────────────┘
│  - LyricPreview       │
│  - ExportView         │
└───────────┬───────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           ProjectViewModel (State)                          │
│  - activeProject: StateFlow<LyricProject>                                    │
│  - playbackState: StateFlow<PlaybackState> (positionMs, isPlaying, loop)    │
│  - selectionState: StateFlow<Selection> (selectedWordIds, selectedLineId)   │
│  - undoRedoStack: UndoManager                                               │
└───────────┬──────────────────────────────────┬──────────────────────────────┘
            │                                  │
            ▼                                  ▼
┌───────────────────────┐          ┌──────────────────────────────────────────┐
│  Parser & Exporter    │          │            Persistence & Network         │
│  - TtmlParser         │          │  - ProjectRepository (Room Database)     │
│  - TtmlSerializer     │          │  - LrclibApiService (Retrofit + OkHttp)  │
│  - LrcParser          │          │  - GeminiTranslationService (REST)       │
│  - SrtParser          │          └──────────────────────────────────────────┘
└───────────────────────┘
```

### Core Domain Models

```kotlin
data class LyricProject(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Untitled Song",
    val artist: String = "Unknown Artist",
    val album: String = "",
    val durationMs: Long = 0L,
    val audioUri: String? = null,
    val agents: List<SingerAgent> = listOf(
        SingerAgent("v1", "Lead Singer", 0xFF8B5CF6),
        SingerAgent("v2", "Backing Vocal", 0xFF10B981)
    ),
    val lines: List<LyricLine> = emptyList(),
    val translations: Map<String, String> = emptyMap(), // lineId to translated text
    val pronunciations: Map<String, String> = emptyMap() // wordId/lineId to phonetics
)

data class LyricLine(
    val id: String = UUID.randomUUID().toString(),
    val singerId: String = "v1",
    val beginMs: Long,
    val endMs: Long,
    val words: List<LyricWord>,
    val isBackground: Boolean = false
)

data class LyricWord(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val beginMs: Long,
    val endMs: Long,
    val singerId: String? = null // Inherits from line if null
)

data class SingerAgent(
    val id: String, // e.g. "v1", "v2"
    val name: String,
    val colorArgb: Long
)
```

---

## 5. Implementation Roadmap & Verification Plan

### Phase 1: Foundation & Project Setup
- Synchronize app naming to "TTML Studio" in `metadata.json` and `strings.xml`.
- Configure Gradle dependencies: AndroidX Media3 (ExoPlayer), Room Database with KSP, Retrofit + OkHttp for LRCLIB and Gemini API.
- Create Room database schemas, entities, DAOs, and repository.

### Phase 2: Domain Parsing & Serialization Engines
- Implement `TtmlParser` and `TtmlSerializer` with full support for Apple Music extensions (`itunes:key`, `ttm:agent`, XML namespaces, timestamps).
- Implement `LrcParser` (standard & word-enhanced) and `SrtParser`.
- Add unit tests verifying parsing and serialization round-trips.

### Phase 3: Audio & Waveform Pipeline
- Build `AudioPlaybackEngine` using Media3 ExoPlayer with loop boundaries and high-frequency position ticker.
- Implement `WaveformExtractor` to decode audio channels into normalized amplitude peaks for timeline rendering.

### Phase 4: DAW Timeline Screen
- Build custom Compose timeline canvas: millisecond ruler, amplitude waveform, vertical playhead marker.
- Interactive word blocks: horizontal dragging, start/end boundary resize grabbers, snapping guides.
- Implement ±10ms / ±50ms micro-nudge controls, multi-word selection, and syllable splitting.
- Implement interactive Tap-to-Sync recording bar with undo and next-word progress tracking.

### Phase 5: Import, Translation, Preview & Export
- Implement SAF Audio and Lyric file pickers + LRCLIB search client.
- Implement Translate & Pronunciation view with offline phonetic transliteration and optional Gemini API integration.
- Implement Apple Music-style lyric preview player with smooth word highlighting.
- Implement TTML Export screen with syntax display, clipboard copy, and SAF file saver.

### Phase 6: Compilation & Verification
- Run `compile_applet` to verify compilation.
- Execute local unit tests for TTML parsing and timestamp calculations.
