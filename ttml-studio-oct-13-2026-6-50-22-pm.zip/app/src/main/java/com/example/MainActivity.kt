package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.export.ExportScreen
import com.example.ui.import.ImportScreen
import com.example.ui.preview.PreviewScreen
import com.example.ui.project.ProjectListDialog
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.TTMLStudioTheme
import com.example.ui.timeline.TimelineScreen
import com.example.ui.translate.TranslateScreen
import com.example.ui.viewmodel.ProjectViewModel

enum class AppScreen(val label: String, val icon: ImageVector) {
    IMPORT("Import", Icons.Default.FileDownload),
    TIMELINE("Timeline", Icons.Default.GraphicEq),
    TRANSLATE("Translate", Icons.Default.Translate),
    PREVIEW("Preview", Icons.Default.PlayCircle),
    EXPORT("Export", Icons.Default.Code)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TTMLStudioTheme {
                MainAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: ProjectViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf(AppScreen.IMPORT) }
    var showProjectDialog by remember { mutableStateOf(false) }

    val project by viewModel.project.collectAsState()

    // Handle back button if on secondary screen
    BackHandler(enabled = currentScreen != AppScreen.TIMELINE && currentScreen != AppScreen.IMPORT) {
        currentScreen = AppScreen.TIMELINE
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(CyanAccent)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "TTML Studio",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = "•  ${project.metadata.title}",
                            fontSize = 13.sp,
                            color = CyanAccent,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showProjectDialog = true },
                        modifier = Modifier.testTag("open_projects_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = "Saved Projects",
                            tint = Color.LightGray
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = StudioSurface,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = StudioSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                AppScreen.values().forEach { screen ->
                    val isSelected = currentScreen == screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentScreen = screen },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.label
                            )
                        },
                        label = {
                            Text(
                                text = screen.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = StudioObsidian,
                            selectedTextColor = CyanAccent,
                            indicatorColor = CyanAccent,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_${screen.name.lowercase()}")
                    )
                }
            }
        },
        containerColor = StudioObsidian
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.IMPORT -> {
                    ImportScreen(
                        viewModel = viewModel,
                        onNavigateToTimeline = { currentScreen = AppScreen.TIMELINE }
                    )
                }
                AppScreen.TIMELINE -> {
                    TimelineScreen(
                        viewModel = viewModel
                    )
                }
                AppScreen.TRANSLATE -> {
                    TranslateScreen(
                        viewModel = viewModel
                    )
                }
                AppScreen.PREVIEW -> {
                    PreviewScreen(
                        viewModel = viewModel
                    )
                }
                AppScreen.EXPORT -> {
                    ExportScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    if (showProjectDialog) {
        ProjectListDialog(
            viewModel = viewModel,
            onDismiss = { showProjectDialog = false }
        )
    }
}
