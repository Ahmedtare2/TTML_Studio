package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.domain.model.Project
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val updatedAt: Long,
    val jsonContent: String
)

@Dao
interface ProjectDao {

    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun getAllProjectsFlow(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProjectById(id: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProject(entity: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProject(id: String)
}

@Database(entities = [ProjectEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ttml_studio_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class ProjectRepository(private val projectDao: ProjectDao) {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val projectAdapter = moshi.adapter(Project::class.java)

    fun getProjectsFlow(): Flow<List<Project>> {
        return projectDao.getAllProjectsFlow().map { entities ->
            entities.mapNotNull { entity ->
                try {
                    projectAdapter.fromJson(entity.jsonContent)
                } catch (e: Exception) {
                    null
                }
            }
        }
    }

    suspend fun getProject(id: String): Project? {
        val entity = projectDao.getProjectById(id) ?: return null
        return try {
            projectAdapter.fromJson(entity.jsonContent)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun saveProject(project: Project) {
        val json = projectAdapter.toJson(project)
        val entity = ProjectEntity(
            id = project.id,
            title = project.metadata.title,
            artist = project.metadata.artist,
            updatedAt = System.currentTimeMillis(),
            jsonContent = json
        )
        projectDao.upsertProject(entity)
    }

    suspend fun deleteProject(id: String) {
        projectDao.deleteProject(id)
    }

    fun exportProjectBackup(project: Project): String {
        return projectAdapter.toJson(project)
    }

    fun importProjectBackup(json: String): Project? {
        return try {
            projectAdapter.fromJson(json)
        } catch (e: Exception) {
            null
        }
    }
}
