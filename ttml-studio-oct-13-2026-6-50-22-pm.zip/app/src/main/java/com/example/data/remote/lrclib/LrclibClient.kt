package com.example.data.remote.lrclib

import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

data class LrclibTrack(
    @Json(name = "id") val id: Long,
    @Json(name = "trackName") val trackName: String,
    @Json(name = "artistName") val artistName: String,
    @Json(name = "albumName") val albumName: String?,
    @Json(name = "duration") val duration: Double?,
    @Json(name = "instrumental") val instrumental: Boolean = false,
    @Json(name = "plainLyrics") val plainLyrics: String?,
    @Json(name = "syncedLyrics") val syncedLyrics: String?
) {
    val hasSynced: Boolean get() = !syncedLyrics.isNullOrBlank()
}

interface LrclibApi {

    @GET("api/search")
    suspend fun search(
        @Query("q") query: String
    ): List<LrclibTrack>

    @GET("api/search")
    suspend fun searchByTrackAndArtist(
        @Query("track_name") trackName: String,
        @Query("artist_name") artistName: String
    ): List<LrclibTrack>
}

object LrclibClient {

    private const val BASE_URL = "https://lrclib.net/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    val api: LrclibApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(LrclibApi::class.java)
    }
}
