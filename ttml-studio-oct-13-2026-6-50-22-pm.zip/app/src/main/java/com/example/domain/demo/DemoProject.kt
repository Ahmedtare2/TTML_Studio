package com.example.domain.demo

import com.example.domain.model.LyricLine
import com.example.domain.model.LyricWord
import com.example.domain.model.Project
import com.example.domain.model.Singer
import com.example.domain.model.SongMetadata
import java.util.UUID

object DemoProjectProvider {

    /**
     * Creates a demo project inspired by Apple Music word-synced duet tracks.
     */
    fun createDemoProject(): Project {
        val leadSinger = Singer("v1", "Alex (Lead)", 0xFF8B5CF6)
        val harmonySinger = Singer("v2", "Maya (Harmony)", 0xFF10B981)
        val bgSinger = Singer("v3", "Choir (BG)", 0xFFF43F5E)

        val lines = listOf(
            LyricLine(
                id = UUID.randomUUID().toString(),
                singerId = "v1",
                beginMs = 3200L,
                endMs = 6800L,
                words = listOf(
                    LyricWord(UUID.randomUUID().toString(), "Starlight", 3200L, 3900L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "falling", 3950L, 4600L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "through", 4650L, 5100L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "the", 5150L, 5400L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "open", 5450L, 6100L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "room", 6150L, 6800L, "v1")
                ),
                translation = "La luz de las estrellas cayendo por la habitación abierta",
                pronunciation = "/ˈstɑːlaɪt ˈfɔːlɪŋ θruː ðə ˈoʊpən ruːm/"
            ),
            LyricLine(
                id = UUID.randomUUID().toString(),
                singerId = "v2",
                beginMs = 7400L,
                endMs = 11200L,
                words = listOf(
                    LyricWord(UUID.randomUUID().toString(), "Echoes", 7400L, 8100L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "whisper", 8150L, 8900L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "what", 8950L, 9300L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "we", 9350L, 9600L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "used", 9650L, 10200L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "to", 10250L, 10500L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "know", 10550L, 11200L, "v2")
                ),
                translation = "Los ecos susurran lo que solíamos saber",
                pronunciation = "/ˈɛkoʊz ˈwɪspər wʌt wiː juːzd tuː noʊ/"
            ),
            LyricLine(
                id = UUID.randomUUID().toString(),
                singerId = "v3",
                beginMs = 11500L,
                endMs = 14200L,
                isBackground = true,
                words = listOf(
                    LyricWord(UUID.randomUUID().toString(), "(Used", 11500L, 12200L, "v3", isBackground = true),
                    LyricWord(UUID.randomUUID().toString(), "to", 12250L, 12600L, "v3", isBackground = true),
                    LyricWord(UUID.randomUUID().toString(), "know)", 12650L, 14200L, "v3", isBackground = true)
                ),
                translation = "(Solíamos saber)",
                pronunciation = "/juːzd tuː noʊ/"
            ),
            LyricLine(
                id = UUID.randomUUID().toString(),
                singerId = "v1",
                beginMs = 14800L,
                endMs = 19200L,
                words = listOf(
                    LyricWord(UUID.randomUUID().toString(), "Catch", 14800L, 15400L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "the", 15450L, 15750L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "frequency", 15800L, 16900L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "before", 16950L, 17600L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "it", 17650L, 17900L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "fades", 17950L, 19200L, "v1")
                ),
                translation = "Atrapa la frecuencia antes de que se desvanezca",
                pronunciation = "/kætʃ ðə ˈfriːkwənsi bɪˈfɔːr ɪt feɪdz/"
            ),
            LyricLine(
                id = UUID.randomUUID().toString(),
                singerId = "v2",
                beginMs = 19600L,
                endMs = 24500L,
                words = listOf(
                    LyricWord(UUID.randomUUID().toString(), "Holding", 19600L, 20400L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "every", 20450L, 21100L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "syllable", 21150L, 22200L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "in", 22250L, 22600L, "v2"),
                    LyricWord(UUID.randomUUID().toString(), "time", 22650L, 24500L, "v2")
                ),
                translation = "Sosteniendo cada sílaba en el tiempo",
                pronunciation = "/ˈhoʊldɪŋ ˈɛvri ˈsɪləbəl ɪn taɪm/"
            ),
            LyricLine(
                id = UUID.randomUUID().toString(),
                singerId = "v1",
                beginMs = 25000L,
                endMs = 30000L,
                words = listOf(
                    LyricWord(UUID.randomUUID().toString(), "Neon", 25000L, 25800L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "horizons", 25850L, 27000L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "bright", 27050L, 27900L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "and", 27950L, 28300L, "v1"),
                    LyricWord(UUID.randomUUID().toString(), "clear", 28350L, 30000L, "v1")
                ),
                translation = "Horizontes de neón brillantes y claros",
                pronunciation = "/ˈniːɒn həˈraɪzənz braɪt ænd klɪər/"
            )
        )

        return Project(
            id = "demo-project-starlight",
            metadata = SongMetadata(
                title = "Starlight Frequency",
                artist = "Alex & Maya",
                album = "Neon Horizons",
                durationMs = 45000L,
                language = "en"
            ),
            singers = listOf(leadSinger, harmonySinger, bgSinger),
            lines = lines
        )
    }
}
