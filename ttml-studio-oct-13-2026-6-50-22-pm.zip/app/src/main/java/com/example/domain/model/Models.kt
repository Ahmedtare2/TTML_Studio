package com.example.domain.model

import java.util.UUID

data class Singer(
    val id: String, // e.g. "v1", "v2", "v3"
    val name: String,
    val colorArgb: Long
) {
    companion object {
        val DefaultV1 = Singer("v1", "Lead (V1)", 0xFF8B5CF6)
        val DefaultV2 = Singer("v2", "Harmony (V2)", 0xFF10B981)
        val DefaultV3 = Singer("v3", "Backing (V3)", 0xFFF43F5E)
        val DefaultV4 = Singer("v4", "Voice 4", 0xFF38BDF8)

        fun defaultSingers(): List<Singer> = listOf(DefaultV1, DefaultV2, DefaultV3, DefaultV4)
    }
}

data class LyricWord(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val beginMs: Long,
    val endMs: Long,
    val singerId: String? = null,
    val isBackground: Boolean = false,
    val phonetic: String? = null
) {
    val durationMs: Long get() = (endMs - beginMs).coerceAtLeast(0L)
}

data class LyricLine(
    val id: String = UUID.randomUUID().toString(),
    val singerId: String = "v1",
    val beginMs: Long,
    val endMs: Long,
    val words: List<LyricWord> = emptyList(),
    val isBackground: Boolean = false,
    val translation: String? = null,
    val pronunciation: String? = null
) {
    val durationMs: Long get() = (endMs - beginMs).coerceAtLeast(0L)
    val plainText: String get() = words.joinToString(" ") { it.text.trim() }.ifEmpty { "" }
}

data class SongMetadata(
    val title: String = "Untitled Song",
    val artist: String = "Unknown Artist",
    val album: String = "",
    val durationMs: Long = 180000L,
    val audioUri: String? = null,
    val audioFileName: String? = null,
    val language: String = "en"
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val metadata: SongMetadata = SongMetadata(),
    val singers: List<Singer> = Singer.defaultSingers(),
    val lines: List<LyricLine> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
