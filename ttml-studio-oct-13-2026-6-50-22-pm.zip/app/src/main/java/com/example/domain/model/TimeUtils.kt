package com.example.domain.model

import java.util.Locale

object TimeUtils {

    /**
     * Formats milliseconds into user-friendly audio timecode (e.g., "01:23.450" or "00:05.120")
     */
    fun formatDisplayTime(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val minutes = (safeMs / 60000) % 60
        val seconds = (safeMs / 1000) % 60
        val millis = safeMs % 1000
        return String.format(Locale.US, "%02d:%02d.%03d", minutes, seconds, millis)
    }

    /**
     * Formats milliseconds into short display time (e.g., "01:23")
     */
    fun formatShortTime(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val minutes = (safeMs / 60000) % 60
        val seconds = (safeMs / 1000) % 60
        return String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }

    /**
     * Formats milliseconds into TTML standard time string (e.g., "00:01:23.450")
     */
    fun formatTtmlTimestamp(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val hours = safeMs / 3600000
        val minutes = (safeMs / 60000) % 60
        val seconds = (safeMs / 1000) % 60
        val millis = safeMs % 1000
        return String.format(Locale.US, "%02d:%02d:%02d.%03d", hours, minutes, seconds, millis)
    }

    /**
     * Formats milliseconds into standard LRC tag format (e.g., "[01:23.45]")
     */
    fun formatLrcTimestamp(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val minutes = (safeMs / 60000) % 60
        val seconds = (safeMs / 1000) % 60
        val centis = (safeMs % 1000) / 10
        return String.format(Locale.US, "[%02d:%02d.%02d]", minutes, seconds, centis)
    }

    /**
     * Formats milliseconds into enhanced LRC word tag (e.g., "<01:23.45>")
     */
    fun formatEnhancedLrcWordTag(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val minutes = (safeMs / 60000) % 60
        val seconds = (safeMs / 1000) % 60
        val centis = (safeMs % 1000) / 10
        return String.format(Locale.US, "<%02d:%02d.%02d>", minutes, seconds, centis)
    }

    /**
     * Formats milliseconds into SubRip (SRT) format (e.g., "00:01:23,450")
     */
    fun formatSrtTimestamp(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val hours = safeMs / 3600000
        val minutes = (safeMs / 60000) % 60
        val seconds = (safeMs / 1000) % 60
        val millis = safeMs % 1000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    /**
     * Parses TTML time string:
     * - "00:01:23.450" (HH:mm:ss.SSS)
     * - "01:23.450" (mm:ss.SSS)
     * - "83.45s" or "83450ms"
     */
    fun parseTtmlTimestamp(raw: String): Long {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return 0L

        // Handle suffix notations
        if (trimmed.endsWith("ms", ignoreCase = true)) {
            return trimmed.removeSuffix("ms").trim().toLongOrNull() ?: 0L
        }
        if (trimmed.endsWith("s", ignoreCase = true)) {
            val sec = trimmed.removeSuffix("s").trim().toDoubleOrNull() ?: 0.0
            return (sec * 1000.0).toLong()
        }

        // Split by colon
        val parts = trimmed.split(":")
        return when (parts.size) {
            3 -> { // HH:mm:ss[.SSS]
                val h = parts[0].toLongOrNull() ?: 0L
                val m = parts[1].toLongOrNull() ?: 0L
                val sMillis = parseSecondsAndFraction(parts[2])
                h * 3600000L + m * 60000L + sMillis
            }
            2 -> { // mm:ss[.SSS]
                val m = parts[0].toLongOrNull() ?: 0L
                val sMillis = parseSecondsAndFraction(parts[1])
                m * 60000L + sMillis
            }
            1 -> { // ss[.SSS]
                parseSecondsAndFraction(parts[0])
            }
            else -> 0L
        }
    }

    /**
     * Parses LRC time string e.g. "[01:23.45]" or "01:23.45" or "<01:23.45>"
     */
    fun parseLrcTimestamp(raw: String): Long {
        val cleaned = raw.replace("[", "").replace("]", "").replace("<", "").replace(">", "").trim()
        val parts = cleaned.split(":")
        if (parts.size >= 2) {
            val m = parts[0].toLongOrNull() ?: 0L
            val sMillis = parseSecondsAndFraction(parts[1])
            return m * 60000L + sMillis
        }
        return parseSecondsAndFraction(cleaned)
    }

    /**
     * Parses SRT time string e.g. "00:01:23,450"
     */
    fun parseSrtTimestamp(raw: String): Long {
        val normalized = raw.replace(",", ".").trim()
        return parseTtmlTimestamp(normalized)
    }

    private fun parseSecondsAndFraction(secPart: String): Long {
        val clean = secPart.trim()
        val dotIndex = clean.indexOf('.')
        if (dotIndex >= 0) {
            val sec = clean.substring(0, dotIndex).toLongOrNull() ?: 0L
            val fractionStr = clean.substring(dotIndex + 1)
            val millis = when (fractionStr.length) {
                1 -> (fractionStr.toLongOrNull() ?: 0L) * 100
                2 -> (fractionStr.toLongOrNull() ?: 0L) * 10
                3 -> fractionStr.toLongOrNull() ?: 0L
                else -> fractionStr.take(3).toLongOrNull() ?: 0L
            }
            return sec * 1000L + millis
        } else {
            val sec = clean.toLongOrNull() ?: 0L
            return sec * 1000L
        }
    }
}
