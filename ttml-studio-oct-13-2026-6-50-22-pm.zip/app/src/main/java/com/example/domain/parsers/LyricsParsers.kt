package com.example.domain.parsers

import com.example.domain.model.LyricLine
import com.example.domain.model.LyricWord
import com.example.domain.model.Project
import com.example.domain.model.Singer
import com.example.domain.model.SongMetadata
import com.example.domain.model.TimeUtils
import java.util.UUID

object LrcParser {

    private val LRC_TAG_REGEX = Regex("""\[(\d{1,2}:\d{2}(?:\.\d{1,3})?)]""")
    private val ENHANCED_WORD_REGEX = Regex("""<(\d{1,2}:\d{2}(?:\.\d{1,3})?)>([^<]+)""")
    private val METADATA_REGEX = Regex("""\[([a-zA-Z]+):([^]]+)]""")

    fun parse(lrcContent: String): Project {
        var title = "Imported LRC"
        var artist = "Unknown Artist"
        var album = ""
        val parsedLines = mutableListOf<LyricLine>()

        val rawLines = lrcContent.lines()
        for (line in rawLines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) continue

            // Check metadata tags e.g. [ti:Song], [ar:Artist], [al:Album]
            val metaMatch = METADATA_REGEX.matchEntire(trimmed)
            if (metaMatch != null) {
                val tag = metaMatch.groupValues[1].lowercase()
                val value = metaMatch.groupValues[2].trim()
                when (tag) {
                    "ti" -> title = value
                    "ar" -> artist = value
                    "al" -> album = value
                }
                continue
            }

            // Find all time tags in the line (could be multiple [01:23.45][02:34.56]Text)
            val timeMatches = LRC_TAG_REGEX.findAll(trimmed).toList()
            if (timeMatches.isNotEmpty()) {
                val textAfterTags = trimmed.replace(LRC_TAG_REGEX, "").trim()

                // Check if text has enhanced word tags like <00:12.34>Word
                val wordMatches = ENHANCED_WORD_REGEX.findAll(textAfterTags).toList()

                for (match in timeMatches) {
                    val lineStartMs = TimeUtils.parseLrcTimestamp(match.groupValues[1])
                    val words = mutableListOf<LyricWord>()

                    if (wordMatches.isNotEmpty()) {
                        for (wIdx in wordMatches.indices) {
                            val wMatch = wordMatches[wIdx]
                            val wStartMs = TimeUtils.parseLrcTimestamp(wMatch.groupValues[1])
                            val wText = wMatch.groupValues[2].trim()
                            val nextStartMs = if (wIdx + 1 < wordMatches.size) {
                                TimeUtils.parseLrcTimestamp(wordMatches[wIdx + 1].groupValues[1])
                            } else {
                                wStartMs + 500L
                            }
                            words.add(
                                LyricWord(
                                    id = UUID.randomUUID().toString(),
                                    text = wText,
                                    beginMs = wStartMs,
                                    endMs = nextStartMs.coerceAtLeast(wStartMs + 50L),
                                    singerId = "v1"
                                )
                            )
                        }
                    } else if (textAfterTags.isNotEmpty()) {
                        // Plain line LRC: split by whitespace with default estimate
                        val rawWords = textAfterTags.split("\\s+".toRegex()).filter { it.isNotBlank() }
                        val defaultLineDur = 3000L
                        val wordDur = if (rawWords.isNotEmpty()) defaultLineDur / rawWords.size else defaultLineDur
                        rawWords.forEachIndexed { i, w ->
                            val s = lineStartMs + (i * wordDur)
                            val e = s + wordDur
                            words.add(
                                LyricWord(
                                    id = UUID.randomUUID().toString(),
                                    text = w,
                                    beginMs = s,
                                    endMs = e,
                                    singerId = "v1"
                                )
                            )
                        }
                    }

                    val lineEndMs = words.lastOrNull()?.endMs ?: (lineStartMs + 3000L)
                    parsedLines.add(
                        LyricLine(
                            id = UUID.randomUUID().toString(),
                            singerId = "v1",
                            beginMs = lineStartMs,
                            endMs = lineEndMs,
                            words = words
                        )
                    )
                }
            }
        }

        val sorted = parsedLines.sortedBy { it.beginMs }
        // Adjust end timestamps of lines without word-end granularity to the start of the next line
        val finalizedLines = sorted.mapIndexed { idx, line ->
            if (line.words.isNotEmpty()) {
                line
            } else {
                val nextStart = sorted.getOrNull(idx + 1)?.beginMs
                val end = if (nextStart != null && nextStart > line.beginMs) {
                    nextStart.coerceAtMost(line.beginMs + 10000L)
                } else {
                    line.beginMs + 3000L
                }
                line.copy(endMs = end)
            }
        }

        return Project(
            metadata = SongMetadata(
                title = title,
                artist = artist,
                album = album,
                durationMs = finalizedLines.lastOrNull()?.endMs?.plus(5000L) ?: 180000L
            ),
            singers = Singer.defaultSingers(),
            lines = finalizedLines
        )
    }

    fun exportToLrc(project: Project): String {
        val sb = StringBuilder()
        sb.append("[ti:${project.metadata.title}]\n")
        sb.append("[ar:${project.metadata.artist}]\n")
        if (project.metadata.album.isNotBlank()) {
            sb.append("[al:${project.metadata.album}]\n")
        }

        project.lines.forEach { line ->
            sb.append(TimeUtils.formatLrcTimestamp(line.beginMs))
            sb.append(line.plainText)
            sb.append("\n")
        }
        return sb.toString()
    }
}

object SrtParser {

    private val TIME_ARROW_REGEX = Regex("""(\d{2}:\d{2}:\d{2}[,\.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,\.]\d{3})""")

    fun parse(srtContent: String): Project {
        val lines = mutableListOf<LyricLine>()
        val blocks = srtContent.split(Regex("""\r?\n\r?\n"""))

        for (block in blocks) {
            val blockLines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (blockLines.size >= 2) {
                // Find line with time arrow
                var timeLineIdx = -1
                var matchResult: MatchResult? = null
                for (i in blockLines.indices) {
                    val m = TIME_ARROW_REGEX.find(blockLines[i])
                    if (m != null) {
                        timeLineIdx = i
                        matchResult = m
                        break
                    }
                }

                if (matchResult != null && timeLineIdx >= 0) {
                    val startMs = TimeUtils.parseSrtTimestamp(matchResult.groupValues[1])
                    val endMs = TimeUtils.parseSrtTimestamp(matchResult.groupValues[2])
                    val textLines = blockLines.drop(timeLineIdx + 1).joinToString(" ")
                    val wordsRaw = textLines.split("\\s+".toRegex()).filter { it.isNotBlank() }

                    val wordList = mutableListOf<LyricWord>()
                    val totalDur = (endMs - startMs).coerceAtLeast(100L * wordsRaw.size)
                    val wordDur = if (wordsRaw.isNotEmpty()) totalDur / wordsRaw.size else totalDur

                    wordsRaw.forEachIndexed { idx, w ->
                        val wStart = startMs + idx * wordDur
                        val wEnd = if (idx == wordsRaw.lastIndex) endMs else wStart + wordDur
                        wordList.add(
                            LyricWord(
                                id = UUID.randomUUID().toString(),
                                text = w,
                                beginMs = wStart,
                                endMs = wEnd,
                                singerId = "v1"
                            )
                        )
                    }

                    lines.add(
                        LyricLine(
                            id = UUID.randomUUID().toString(),
                            singerId = "v1",
                            beginMs = startMs,
                            endMs = endMs,
                            words = wordList
                        )
                    )
                }
            }
        }

        return Project(
            metadata = SongMetadata(title = "Imported Subtitles"),
            singers = Singer.defaultSingers(),
            lines = lines.sortedBy { it.beginMs }
        )
    }

    fun exportToSrt(project: Project): String {
        val sb = StringBuilder()
        project.lines.forEachIndexed { index, line ->
            sb.append("${index + 1}\n")
            sb.append("${TimeUtils.formatSrtTimestamp(line.beginMs)} --> ${TimeUtils.formatSrtTimestamp(line.endMs)}\n")
            sb.append("${line.plainText}\n\n")
        }
        return sb.toString()
    }
}

object TxtParser {

    /**
     * Splits plain text lyrics into lines and words.
     * Default timestamps are spaced out or initialized for tap-to-sync.
     */
    fun parse(rawText: String, initialSpacingMs: Long = 3000L): Project {
        val lines = mutableListOf<LyricLine>()
        var currentMs = 1000L

        rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { lineText ->
            val wordsRaw = lineText.split("\\s+".toRegex()).filter { it.isNotBlank() }
            val words = mutableListOf<LyricWord>()
            val lineDuration = (initialSpacingMs).coerceAtLeast(wordsRaw.size * 300L)
            val wordDuration = if (wordsRaw.isNotEmpty()) lineDuration / wordsRaw.size else lineDuration

            wordsRaw.forEachIndexed { idx, w ->
                val wStart = currentMs + idx * wordDuration
                val wEnd = wStart + wordDuration
                words.add(
                    LyricWord(
                        id = UUID.randomUUID().toString(),
                        text = w,
                        beginMs = wStart,
                        endMs = wEnd,
                        singerId = "v1"
                    )
                )
            }

            val lineEnd = words.lastOrNull()?.endMs ?: (currentMs + lineDuration)
            lines.add(
                LyricLine(
                    id = UUID.randomUUID().toString(),
                    singerId = "v1",
                    beginMs = currentMs,
                    endMs = lineEnd,
                    words = words
                )
            )
            currentMs = lineEnd + 1000L // 1-second gap between lines
        }

        return Project(
            metadata = SongMetadata(title = "Pasted Lyrics"),
            singers = Singer.defaultSingers(),
            lines = lines
        )
    }
}
