package com.example.domain.translate

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class ArabicTransliterationStyle(val displayName: String) {
    ALA_LC("ALA-LC (Standard Academic)"),
    DIN_31635("DIN 31635 (Diacritics)"),
    PRACTICAL("Practical Arabizi / Chat")
}

data class TargetLanguage(
    val code: String,
    val name: String,
    val flag: String
) {
    companion object {
        val ALL = listOf(
            TargetLanguage("es", "Spanish", "🇪🇸"),
            TargetLanguage("fr", "French", "🇫🇷"),
            TargetLanguage("de", "German", "🇩🇪"),
            TargetLanguage("it", "Italian", "🇮🇹"),
            TargetLanguage("ja", "Japanese", "🇯🇵"),
            TargetLanguage("ko", "Korean", "🇰🇷"),
            TargetLanguage("ar", "Arabic", "🇸🇦"),
            TargetLanguage("pt", "Portuguese", "🇧🇷"),
            TargetLanguage("zh", "Chinese", "🇨🇳"),
            TargetLanguage("ru", "Russian", "🇷🇺"),
            TargetLanguage("en", "English", "🇺🇸")
        )
    }
}

object PhoneticEngine {

    /**
     * Converts text into an approximate phonetic transcription (IPA or practical pronunciation).
     */
    fun toPracticalPhonetics(text: String): String {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return ""

        // Check if Arabic text
        if (isArabic(cleaned)) {
            return transliterateArabic(cleaned, ArabicTransliterationStyle.ALA_LC)
        }

        // Basic Romanic phonetic approximations for common words / letters
        return cleaned.split(" ").joinToString(" ") { word ->
            transcribeWord(word)
        }
    }

    fun isArabic(text: String): Boolean {
        return text.any { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' }
    }

    /**
     * Transliterates Arabic script lyrics according to chosen academic or practical style.
     */
    fun transliterateArabic(
        arabicText: String,
        style: ArabicTransliterationStyle = ArabicTransliterationStyle.ALA_LC
    ): String {
        val sb = StringBuilder()
        for (ch in arabicText) {
            val trans = when (ch) {
                'ا', 'أ', 'إ', 'آ' -> if (style == ArabicTransliterationStyle.PRACTICAL) "a" else "ā"
                'ب' -> "b"
                'ت' -> "t"
                'ث' -> if (style == ArabicTransliterationStyle.PRACTICAL) "th" else "th"
                'ج' -> if (style == ArabicTransliterationStyle.PRACTICAL) "j" else "j"
                'ح' -> if (style == ArabicTransliterationStyle.PRACTICAL) "7" else "ḥ"
                'خ' -> if (style == ArabicTransliterationStyle.PRACTICAL) "5" else "kh"
                'د' -> "d"
                'ذ' -> if (style == ArabicTransliterationStyle.PRACTICAL) "dh" else "dh"
                'ر' -> "r"
                'ز' -> "z"
                'س' -> "s"
                'ش' -> "sh"
                'ص' -> if (style == ArabicTransliterationStyle.PRACTICAL) "9" else "ṣ"
                'ض' -> if (style == ArabicTransliterationStyle.PRACTICAL) "9'" else "ḍ"
                'ط' -> if (style == ArabicTransliterationStyle.PRACTICAL) "6" else "ṭ"
                'ظ' -> if (style == ArabicTransliterationStyle.PRACTICAL) "6'" else "ẓ"
                'ع' -> if (style == ArabicTransliterationStyle.PRACTICAL) "3" else "‘"
                'غ' -> if (style == ArabicTransliterationStyle.PRACTICAL) "3'" else "gh"
                'ف' -> "f"
                'ق' -> if (style == ArabicTransliterationStyle.PRACTICAL) "8" else "q"
                'ك' -> "k"
                'ل' -> "l"
                'م' -> "m"
                'ن' -> "n"
                'ه' -> "h"
                'و' -> if (style == ArabicTransliterationStyle.PRACTICAL) "w" else "ū"
                'ي', 'ى' -> if (style == ArabicTransliterationStyle.PRACTICAL) "y" else "ī"
                'ة' -> "h"
                'ء', 'ئ', 'ؤ' -> "'"
                'َ' -> "a"
                'ُ' -> "u"
                'ِ' -> "i"
                'ّ' -> "" // Shaddah
                'ْ' -> "" // Sukun
                ' ' -> " "
                else -> ch.toString()
            }
            sb.append(trans)
        }
        return sb.toString()
    }

    private fun transcribeWord(word: String): String {
        val lower = word.lowercase()
        // Common musical phonetic dictionary replacements
        val dict = mapOf(
            "the" to "ðə", "you" to "juː", "love" to "lʌv", "heart" to "hɑːt",
            "night" to "naɪt", "day" to "deɪ", "forever" to "fərˈɛvər",
            "baby" to "ˈbeɪbi", "time" to "taɪm", "light" to "laɪt",
            "world" to "wɜːld", "shine" to "ʃaɪn", "dream" to "driːm",
            "away" to "əˈweɪ", "never" to "ˈnɛvər", "always" to "ˈɔːlweɪz"
        )
        return dict[lower] ?: "/$word/"
    }
}

object GeminiTranslationService {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Translates a list of lyric lines using Gemini 3.5 Flash REST API.
     * Preserves line indexing and line-by-line alignment.
     */
    suspend fun translateLines(
        lines: List<String>,
        targetLanguageName: String
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String ?: ""
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is not configured in the Secrets panel. Set GEMINI_API_KEY in .env to enable AI translation.")
            )
        }

        try {
            val linesJsonArray = JSONArray()
            lines.forEach { linesJsonArray.put(it) }

            val prompt = """
                Translate the following song lyric lines into $targetLanguageName.
                Maintain the poetic song tone, cadence, and line-by-line structure.
                Respond with a valid JSON array of strings containing EXACTLY ${lines.size} elements, matching the original line order.
                Do not include markdown blocks or extra text. Only JSON.
                Original lines:
                $linesJsonArray
            """.trimIndent()

            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.3)
                })
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(requestBody)
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "HTTP ${response.code}"
                return@withContext Result.failure(Exception("Gemini translation error: $errorBody"))
            }

            val respBodyStr = response.body?.string() ?: ""
            val respJson = JSONObject(respBodyStr)
            val candidates = respJson.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text") ?: "[]"

            val translatedArray = JSONArray(text.trim().removePrefix("```json").removeSuffix("```").trim())
            val result = mutableListOf<String>()
            for (i in 0 until lines.size) {
                result.add(translatedArray.optString(i, lines[i]))
            }
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
