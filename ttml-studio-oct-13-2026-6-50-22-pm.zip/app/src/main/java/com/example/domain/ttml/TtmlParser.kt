package com.example.domain.ttml

import android.util.Xml
import com.example.domain.model.LyricLine
import com.example.domain.model.LyricWord
import com.example.domain.model.Project
import com.example.domain.model.Singer
import com.example.domain.model.SongMetadata
import com.example.domain.model.TimeUtils
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.util.UUID

object TtmlParser {

    /**
     * Robustly parses a TTML XML document using Android's native XmlPullParser.
     */
    fun parse(xmlContent: String): Result<Project> = runCatching {
        val parser = Xml.newPullParser()
        parser.setInput(StringReader(xmlContent))

        var title = "Imported TTML"
        var artist = "Unknown Artist"
        var album = ""
        var language = "en"
        val singers = mutableListOf<Singer>()
        val lines = mutableListOf<LyricLine>()

        var eventType = parser.eventType
        var currentTag = ""
        var inHead = false
        var inBody = false

        // Current line accumulator
        var currentLineBegin: Long = 0L
        var currentLineEnd: Long = 0L
        var currentLineAgent: String = "v1"
        var currentLineIsBg = false
        var currentWords = mutableListOf<LyricWord>()
        var lineTextFallback = StringBuilder()

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.lowercase()
                    currentTag = name

                    if (name == "tt") {
                        val lang = parser.getAttributeValue(null, "xml:lang")
                            ?: parser.getAttributeValue(null, "lang")
                        if (!lang.isNullOrBlank()) language = lang
                    } else if (name == "head") {
                        inHead = true
                    } else if (name == "body") {
                        inBody = true
                    } else if (inHead) {
                        if (name.endsWith("title")) {
                            val text = parser.nextText().trim()
                            if (text.isNotEmpty()) title = text
                        } else if (name.endsWith("agent")) {
                            val id = parser.getAttributeValue(null, "xml:id")
                                ?: parser.getAttributeValue(null, "id")
                                ?: "v${singers.size + 1}"
                            val agentName = parser.nextText().trim().ifEmpty { id.uppercase() }
                            val color = when (id) {
                                "v1" -> 0xFF8B5CF6
                                "v2" -> 0xFF10B981
                                "v3" -> 0xFFF43F5E
                                else -> 0xFF38BDF8
                            }
                            singers.add(Singer(id, agentName, color))
                        }
                    } else if (inBody) {
                        if (name == "p") {
                            // Start of a lyric line
                            val beginStr = parser.getAttributeValue(null, "begin") ?: "00:00.000"
                            val endStr = parser.getAttributeValue(null, "end") ?: ""
                            val durStr = parser.getAttributeValue(null, "dur") ?: ""
                            val agentStr = parser.getAttributeValue(null, "ttm:agent")
                                ?: parser.getAttributeValue(null, "agent")
                                ?: "v1"
                            val itunesKey = parser.getAttributeValue(null, "itunes:key") ?: ""
                            val role = parser.getAttributeValue(null, "ttm:role")
                                ?: parser.getAttributeValue(null, "role") ?: ""

                            currentLineBegin = TimeUtils.parseTtmlTimestamp(beginStr)
                            currentLineEnd = if (endStr.isNotEmpty()) {
                                TimeUtils.parseTtmlTimestamp(endStr)
                            } else if (durStr.isNotEmpty()) {
                                currentLineBegin + TimeUtils.parseTtmlTimestamp(durStr)
                            } else {
                                currentLineBegin + 3000L
                            }

                            currentLineAgent = agentStr
                            currentLineIsBg = itunesKey.equals("bg", ignoreCase = true) ||
                                    role.contains("bg", ignoreCase = true)
                            currentWords = mutableListOf()
                            lineTextFallback = StringBuilder()
                        } else if (name == "span") {
                            // Word or phrase span
                            val wordBeginStr = parser.getAttributeValue(null, "begin")
                            val wordEndStr = parser.getAttributeValue(null, "end")
                            val wordAgent = parser.getAttributeValue(null, "ttm:agent")
                            val wordRole = parser.getAttributeValue(null, "ttm:role") ?: ""

                            val wordText = parser.nextText()
                            if (wordText.isNotEmpty()) {
                                val wBegin = if (!wordBeginStr.isNullOrEmpty()) {
                                    TimeUtils.parseTtmlTimestamp(wordBeginStr)
                                } else {
                                    currentLineBegin
                                }
                                val wEnd = if (!wordEndStr.isNullOrEmpty()) {
                                    TimeUtils.parseTtmlTimestamp(wordEndStr)
                                } else {
                                    wBegin + 500L
                                }

                                currentWords.add(
                                    LyricWord(
                                        id = UUID.randomUUID().toString(),
                                        text = wordText,
                                        beginMs = wBegin,
                                        endMs = wEnd.coerceAtLeast(wBegin + 50L),
                                        singerId = wordAgent ?: currentLineAgent,
                                        isBackground = wordRole.contains("bg", ignoreCase = true) || currentLineIsBg
                                    )
                                )
                            }
                        }
                    }
                }

                XmlPullParser.TEXT -> {
                    if (inBody && currentTag == "p") {
                        val text = parser.text
                        if (!text.isNullOrBlank()) {
                            lineTextFallback.append(text)
                        }
                    }
                }

                XmlPullParser.END_TAG -> {
                    val name = parser.name.lowercase()
                    if (name == "head") {
                        inHead = false
                    } else if (name == "body") {
                        inBody = false
                    } else if (name == "p") {
                        // If no child spans were parsed, synthesize word blocks from fallback text
                        if (currentWords.isEmpty() && lineTextFallback.isNotBlank()) {
                            val rawWords = lineTextFallback.toString().trim().split("\\s+".toRegex())
                            if (rawWords.isNotEmpty()) {
                                val totalDur = (currentLineEnd - currentLineBegin).coerceAtLeast(100L * rawWords.size)
                                val wordDur = totalDur / rawWords.size
                                rawWords.forEachIndexed { idx, w ->
                                    val wStart = currentLineBegin + idx * wordDur
                                    val wEnd = if (idx == rawWords.lastIndex) currentLineEnd else wStart + wordDur
                                    currentWords.add(
                                        LyricWord(
                                            id = UUID.randomUUID().toString(),
                                            text = w,
                                            beginMs = wStart,
                                            endMs = wEnd,
                                            singerId = currentLineAgent,
                                            isBackground = currentLineIsBg
                                        )
                                    )
                                }
                            }
                        }

                        // Align line bounds to words if words exist
                        val actualLineBegin = currentWords.firstOrNull()?.beginMs ?: currentLineBegin
                        val actualLineEnd = currentWords.lastOrNull()?.endMs ?: currentLineEnd

                        lines.add(
                            LyricLine(
                                id = UUID.randomUUID().toString(),
                                singerId = currentLineAgent,
                                beginMs = actualLineBegin,
                                endMs = actualLineEnd.coerceAtLeast(actualLineBegin + 200L),
                                words = currentWords,
                                isBackground = currentLineIsBg
                            )
                        )
                    }
                }
            }
            eventType = parser.next()
        }

        // Sort lines chronologically
        val sortedLines = lines.sortedBy { it.beginMs }
        val songDuration = sortedLines.lastOrNull()?.endMs?.let { it + 5000L } ?: 180000L

        val effectiveSingers = if (singers.isNotEmpty()) singers else Singer.defaultSingers()

        Project(
            id = UUID.randomUUID().toString(),
            metadata = SongMetadata(
                title = title,
                artist = artist,
                album = album,
                durationMs = songDuration,
                language = language
            ),
            singers = effectiveSingers,
            lines = sortedLines
        )
    }
}
