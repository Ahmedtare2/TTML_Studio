package com.example.domain.ttml

import com.example.domain.model.Project
import com.example.domain.model.TimeUtils

enum class TtmlProfile(val displayName: String) {
    APPLE_MUSIC("Apple Music Compatible"),
    STANDARD_W3C("Standard W3C TTML")
}

data class TtmlValidationReport(
    val isValid: Boolean,
    val errors: List<String> = emptyList(),
    val warnings: List<String> = emptyList(),
    val lineCount: Int = 0,
    val wordCount: Int = 0
)

object TtmlSerializer {

    /**
     * Serializes a Project into complete, well-formed TTML XML.
     */
    fun serialize(project: Project, profile: TtmlProfile = TtmlProfile.APPLE_MUSIC): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")

        val lang = project.metadata.language.ifBlank { "en" }
        if (profile == TtmlProfile.APPLE_MUSIC) {
            sb.append("<tt xmlns=\"http://www.w3.org/ns/ttml\"\n")
            sb.append("    xmlns:ttm=\"http://www.w3.org/ns/ttml#metadata\"\n")
            sb.append("    xmlns:itunes=\"http://music.apple.com/lyric-ttml\"\n")
            sb.append("    xml:lang=\"$lang\">\n")
        } else {
            sb.append("<tt xmlns=\"http://www.w3.org/ns/ttml\"\n")
            sb.append("    xmlns:ttm=\"http://www.w3.org/ns/ttml#metadata\"\n")
            sb.append("    xml:lang=\"$lang\">\n")
        }

        // Head & Metadata
        sb.append("  <head>\n")
        sb.append("    <metadata>\n")
        sb.append("      <ttm:title>${escapeXml(project.metadata.title)}</ttm:title>\n")
        if (profile == TtmlProfile.APPLE_MUSIC) {
            if (project.metadata.artist.isNotBlank()) {
                sb.append("      <itunes:artist>${escapeXml(project.metadata.artist)}</itunes:artist>\n")
            }
            if (project.metadata.album.isNotBlank()) {
                sb.append("      <itunes:album>${escapeXml(project.metadata.album)}</itunes:album>\n")
            }
        }

        // Singers / Agents
        project.singers.forEach { singer ->
            sb.append("      <ttm:agent type=\"person\" xml:id=\"${singer.id}\">${escapeXml(singer.name)}</ttm:agent>\n")
        }

        sb.append("    </metadata>\n")
        sb.append("  </head>\n")

        // Body & Div & Paragraphs
        sb.append("  <body>\n")
        sb.append("    <div>\n")

        project.lines.forEach { line ->
            val pBegin = TimeUtils.formatTtmlTimestamp(line.beginMs)
            val pEnd = TimeUtils.formatTtmlTimestamp(line.endMs)
            val agentAttr = " ttm:agent=\"${line.singerId}\""
            val bgAttr = if (line.isBackground) {
                if (profile == TtmlProfile.APPLE_MUSIC) " itunes:key=\"bg\"" else " ttm:role=\"x-bg\""
            } else ""

            sb.append("      <p begin=\"$pBegin\" end=\"$pEnd\"$agentAttr$bgAttr>\n")

            if (line.words.isNotEmpty()) {
                line.words.forEachIndexed { index, word ->
                    val wBegin = TimeUtils.formatTtmlTimestamp(word.beginMs)
                    val wEnd = TimeUtils.formatTtmlTimestamp(word.endMs)
                    val isLast = index == line.words.lastIndex
                    // In Apple Music TTML, whitespace between words is preserved in the span text
                    val spaceSuffix = if (isLast) "" else " "
                    val textEscaped = escapeXml(word.text) + spaceSuffix
                    val wordAgentAttr = if (word.singerId != null && word.singerId != line.singerId) {
                        " ttm:agent=\"${word.singerId}\""
                    } else ""

                    sb.append("        <span begin=\"$wBegin\" end=\"$wEnd\"$wordAgentAttr>$textEscaped</span>\n")
                }
            } else {
                // Empty line or whole-line text
                sb.append("        <span begin=\"$pBegin\" end=\"$pEnd\">${escapeXml(line.plainText)}</span>\n")
            }

            sb.append("      </p>\n")
        }

        sb.append("    </div>\n")
        sb.append("  </body>\n")
        sb.append("</tt>\n")

        return sb.toString()
    }

    /**
     * Validates project data before exporting to ensure chronological order and valid spans.
     */
    fun validate(project: Project): TtmlValidationReport {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        var totalWords = 0

        if (project.lines.isEmpty()) {
            warnings.add("Project contains no lyric lines.")
        }

        var prevLineBegin = -1L
        project.lines.forEachIndexed { lIndex, line ->
            val lineNum = lIndex + 1
            if (line.beginMs < 0) {
                errors.add("Line $lineNum has negative start timestamp (${line.beginMs}ms).")
            }
            if (line.endMs < line.beginMs) {
                errors.add("Line $lineNum ends (${line.endMs}ms) before it starts (${line.beginMs}ms).")
            }
            if (line.beginMs < prevLineBegin && !line.isBackground) {
                warnings.add("Line $lineNum starts earlier than previous line (possible overlap).")
            }
            prevLineBegin = line.beginMs

            var prevWordBegin = -1L
            line.words.forEachIndexed { wIndex, word ->
                totalWords++
                val wordNum = wIndex + 1
                if (word.beginMs < 0) {
                    errors.add("Line $lineNum, Word $wordNum ('${word.text}') has negative start timestamp.")
                }
                if (word.endMs < word.beginMs) {
                    errors.add("Line $lineNum, Word $wordNum ('${word.text}') end is earlier than begin.")
                }
                if (word.beginMs < prevWordBegin) {
                    warnings.add("Line $lineNum, Word $wordNum ('${word.text}') overlaps previous word.")
                }
                prevWordBegin = word.beginMs
            }
        }

        return TtmlValidationReport(
            isValid = errors.isEmpty(),
            errors = errors,
            warnings = warnings,
            lineCount = project.lines.size,
            wordCount = totalWords
        )
    }

    private fun escapeXml(input: String): String {
        return input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
