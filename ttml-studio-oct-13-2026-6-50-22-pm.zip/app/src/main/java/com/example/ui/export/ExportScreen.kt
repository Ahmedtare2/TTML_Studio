package com.example.ui.export

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TimeUtils
import com.example.domain.ttml.TtmlProfile
import com.example.domain.ttml.TtmlSerializer
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.viewmodel.ProjectViewModel

@Composable
fun ExportScreen(
    viewModel: ProjectViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val project by viewModel.project.collectAsState()

    var selectedProfile by remember { mutableStateOf(TtmlProfile.APPLE_MUSIC) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: XML Code, 1: Validation, 2: Structure

    val generatedTtml = remember(project, selectedProfile) {
        TtmlSerializer.serialize(project, selectedProfile)
    }

    val validationReport = remember(project) {
        TtmlSerializer.validate(project)
    }

    // Save File via SAF CreateDocument
    val saveFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/xml")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(generatedTtml.toByteArray())
                }
                Toast.makeText(context, "Saved TTML file successfully!", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Save error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun copyTtmlToClipboard() {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("TTML Lyrics", generatedTtml)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied All TTML to Clipboard!", Toast.LENGTH_SHORT).show()
    }

    fun shareTtml() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/xml"
            putExtra(Intent.EXTRA_SUBJECT, "${project.metadata.title} - TTML Lyrics")
            putExtra(Intent.EXTRA_TEXT, generatedTtml)
        }
        context.startActivity(Intent.createChooser(intent, "Share TTML Lyrics"))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StudioObsidian)
    ) {
        // TOP HEADER: Profile selector & Export Actions
        Surface(
            color = StudioSurface,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "TTML Export & Generator",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Apple Music synchronized lyrics XML",
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )
                    }

                    // Profile Filter Chips
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TtmlProfile.values().forEach { profile ->
                            FilterChip(
                                selected = selectedProfile == profile,
                                onClick = { selectedProfile = profile },
                                label = { Text(if (profile == TtmlProfile.APPLE_MUSIC) "Apple Music" else "Standard", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanAccent.copy(alpha = 0.25f),
                                    selectedLabelColor = CyanAccent
                                )
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Action Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { copyTtmlToClipboard() },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = StudioObsidian),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("copy_all_ttml_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Copy All TTML", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            val defaultName = "${project.metadata.title.replace("\\s+".toRegex(), "_")}.ttml"
                            saveFileLauncher.launch(defaultName)
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_ttml_file_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Export File")
                    }

                    IconButton(
                        onClick = { shareTtml() },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(StudioSurfaceVariant)
                            .testTag("share_ttml_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = CyanAccent)
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Navigation Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = StudioSurface,
                    contentColor = CyanAccent,
                    edgePadding = 0.dp
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("XML Code View") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Validation ")
                                if (validationReport.isValid) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldAccent, modifier = Modifier.size(14.dp))
                                } else {
                                    Icon(Icons.Default.Error, contentDescription = null, tint = Color.Red, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Structure (${validationReport.lineCount} Lines)") }
                    )
                }
            }
        }

        // TAB CONTENTS
        when (selectedTab) {
            0 -> {
                // XML CODE VIEWER
                SelectionContainer {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .background(StudioSurfaceCard, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        val lines = generatedTtml.lines()
                        itemsIndexed(lines) { idx, lineText ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                            ) {
                                Text(
                                    text = String.format("%3d  ", idx + 1),
                                    color = Color.DarkGray,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = lineText,
                                    color = when {
                                        lineText.contains("begin=") || lineText.contains("end=") -> CyanAccent
                                        lineText.contains("<ttm:") || lineText.contains("<itunes:") -> AmberAccent
                                        lineText.contains("<span") || lineText.contains("<p") -> Color(0xFFA5B4FC)
                                        else -> Color.LightGray
                                    },
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            1 -> {
                // VALIDATION REPORT
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (validationReport.isValid) EmeraldAccent.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (validationReport.isValid) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (validationReport.isValid) EmeraldAccent else Color.Red,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (validationReport.isValid) "TTML is Valid & Ready" else "Validation Errors Detected",
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${validationReport.lineCount} Lines • ${validationReport.wordCount} Syllable Spans",
                                        color = Color.LightGray,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }

                    if (validationReport.errors.isNotEmpty()) {
                        item {
                            Text("Errors (${validationReport.errors.size})", color = Color.Red, fontWeight = FontWeight.Bold)
                        }
                        itemsIndexed(validationReport.errors) { _, err ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = StudioSurfaceVariant),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Error, contentDescription = null, tint = Color.Red, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(err, color = Color.White, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    if (validationReport.warnings.isNotEmpty()) {
                        item {
                            Text("Warnings (${validationReport.warnings.size})", color = AmberAccent, fontWeight = FontWeight.Bold)
                        }
                        itemsIndexed(validationReport.warnings) { _, warn ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = StudioSurfaceVariant),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = AmberAccent, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(warn, color = Color.White, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // STRUCTURE INSPECTOR
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(project.lines) { index, line ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Line #${index + 1} (${line.singerId.uppercase()})",
                                        color = CyanAccent,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "${TimeUtils.formatDisplayTime(line.beginMs)} - ${TimeUtils.formatDisplayTime(line.endMs)}",
                                        color = Color.Gray,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = line.plainText,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "${line.words.size} word spans: " + line.words.joinToString(", ") { "${it.text} [${it.beginMs}-${it.endMs}ms]" },
                                    color = Color.DarkGray,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
