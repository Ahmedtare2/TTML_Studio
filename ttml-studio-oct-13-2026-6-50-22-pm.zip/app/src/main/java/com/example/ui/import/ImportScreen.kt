package com.example.ui.import

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.lrclib.LrclibTrack
import com.example.domain.model.TimeUtils
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.viewmodel.ProjectViewModel

@Composable
fun ImportScreen(
    viewModel: ProjectViewModel,
    onNavigateToTimeline: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val project by viewModel.project.collectAsState()
    val audioState by viewModel.audioEngine.audioState.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val searchError by viewModel.searchError.collectAsState()

    var showPasteDialog by remember { mutableStateOf(false) }
    var showLrclibDialog by remember { mutableStateOf(false) }
    var showMetadataDialog by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    // Audio file picker
    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = queryFileName(context.contentResolver, uri) ?: "audio_track"
            viewModel.loadAudio(uri, fileName)
            statusMessage = "Loaded audio: $fileName"
        }
    }

    // Lyrics file picker (TTML, LRC, SRT, TXT)
    val lyricsPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = queryFileName(context.contentResolver, uri) ?: "lyrics"
            try {
                val content = context.contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader().readText()
                } ?: ""

                when {
                    fileName.endsWith(".ttml", ignoreCase = true) || content.contains("<tt") -> {
                        viewModel.importTtml(content)
                        statusMessage = "Imported TTML: $fileName"
                    }
                    fileName.endsWith(".srt", ignoreCase = true) -> {
                        viewModel.importSrt(content)
                        statusMessage = "Imported SRT: $fileName"
                    }
                    fileName.endsWith(".lrc", ignoreCase = true) -> {
                        viewModel.importLrc(content)
                        statusMessage = "Imported LRC: $fileName"
                    }
                    else -> {
                        viewModel.importText(content)
                        statusMessage = "Imported Text: $fileName"
                    }
                }
            } catch (e: Exception) {
                statusMessage = "Import error: ${e.localizedMessage}"
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StudioObsidian)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Current Project Summary Card
        Card(
            colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = project.metadata.title,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${project.metadata.artist} • ${project.metadata.album.ifEmpty { "Single" }}",
                            color = Color.LightGray,
                            fontSize = 13.sp
                        )
                    }

                    OutlinedButton(
                        onClick = { showMetadataDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanAccent)
                    ) {
                        Text("Edit Info")
                    }
                }

                Spacer(Modifier.height(12.dp))
                Divider(color = StudioBorder)
                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Audio Source", color = Color.Gray, fontSize = 11.sp)
                        Text(
                            text = if (audioState.hasAudioSource) audioState.audioTitle else "None loaded",
                            color = if (audioState.hasAudioSource) EmeraldAccent else AmberAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Column {
                        Text("Lines / Words", color = Color.Gray, fontSize = 11.sp)
                        Text(
                            text = "${project.lines.size} lines (${project.lines.sumOf { it.words.size }} words)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Column {
                        Text("Duration", color = Color.Gray, fontSize = 11.sp)
                        Text(
                            text = TimeUtils.formatShortTime(project.metadata.durationMs),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (project.lines.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = onNavigateToTimeline,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = StudioObsidian),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Open In Timeline Editor", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        statusMessage?.let { msg ->
            Text(
                text = msg,
                color = CyanAccent,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }

        Text(
            text = "Import & Sources",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        // Action 1: Pick Audio File
        ImportOptionCard(
            title = "Import Audio File",
            subtitle = "MP3, WAV, FLAC, M4A, OGG from device storage",
            icon = Icons.Default.Audiotrack,
            iconTint = EmeraldAccent,
            buttonText = "Select Audio",
            testTag = "import_audio_button",
            onClick = {
                audioPicker.launch(arrayOf("audio/*", "application/ogg"))
            }
        )

        // Action 2: Pick Lyrics File
        ImportOptionCard(
            title = "Import Lyrics Document",
            subtitle = ".ttml (Apple Music), .lrc (standard/word), .srt, .txt",
            icon = Icons.Default.Description,
            iconTint = CyanAccent,
            buttonText = "Select Lyrics File",
            testTag = "import_lyrics_file_button",
            onClick = {
                lyricsPicker.launch(arrayOf("*/*"))
            }
        )

        // Action 3: LRCLIB Online Search
        ImportOptionCard(
            title = "Search LRCLIB Online",
            subtitle = "Find synchronized lyrics by title and artist via lrclib.net",
            icon = Icons.Default.CloudDownload,
            iconTint = AmberAccent,
            buttonText = "Search LRCLIB",
            testTag = "search_lrclib_button",
            onClick = { showLrclibDialog = true }
        )

        // Action 4: Paste Lyrics Manually
        ImportOptionCard(
            title = "Paste Lyrics Manually",
            subtitle = "Directly paste plain text or LRC format lines",
            icon = Icons.Default.ContentPaste,
            iconTint = Color(0xFFA855F7),
            buttonText = "Paste Text",
            testTag = "paste_lyrics_button",
            onClick = { showPasteDialog = true }
        )

        // Action 5: Load Demo Project
        ImportOptionCard(
            title = "Load Duet Demo Project",
            subtitle = "Preload 'Starlight Frequency' duet with Apple Music word sync",
            icon = Icons.Default.LibraryMusic,
            iconTint = Color(0xFFF43F5E),
            buttonText = "Load Demo",
            testTag = "load_demo_button",
            onClick = {
                viewModel.loadDemoProject()
                statusMessage = "Loaded duet demo project!"
            }
        )
    }

    // Paste Dialog
    if (showPasteDialog) {
        var pastedText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPasteDialog = false },
            title = { Text("Paste Lyrics") },
            text = {
                Column {
                    Text("Paste lyrics text or standard LRC. Words will be parsed automatically:")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pastedText,
                        onValueChange = { pastedText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        placeholder = { Text("Starlight falling through the room\nEchoes whisper what we used to know...") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pastedText.isNotBlank()) {
                            if (pastedText.contains("[")) {
                                viewModel.importLrc(pastedText)
                            } else {
                                viewModel.importText(pastedText)
                            }
                            statusMessage = "Imported pasted lyrics!"
                        }
                        showPasteDialog = false
                    }
                ) {
                    Text("Import")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPasteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Metadata Dialog
    if (showMetadataDialog) {
        var titleInput by remember { mutableStateOf(project.metadata.title) }
        var artistInput by remember { mutableStateOf(project.metadata.artist) }
        var albumInput by remember { mutableStateOf(project.metadata.album) }

        AlertDialog(
            onDismissRequest = { showMetadataDialog = false },
            title = { Text("Song Metadata") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Song Title") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = artistInput,
                        onValueChange = { artistInput = it },
                        label = { Text("Artist") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = albumInput,
                        onValueChange = { albumInput = it },
                        label = { Text("Album") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateMetadata(titleInput, artistInput, albumInput)
                        showMetadataDialog = false
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showMetadataDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // LRCLIB Search Dialog
    if (showLrclibDialog) {
        var searchQuery by remember { mutableStateOf(project.metadata.title.ifEmpty { "Bohemian Rhapsody" }) }

        AlertDialog(
            onDismissRequest = { showLrclibDialog = false },
            title = { Text("Search LRCLIB Online") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Title or artist...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            onClick = { viewModel.searchLrclib(searchQuery) }
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = CyanAccent)
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    if (isSearching) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = CyanAccent)
                        }
                    } else if (searchError != null) {
                        Text(searchError ?: "", color = Color.Red, fontSize = 13.sp)
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(searchResults) { track ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = StudioSurfaceVariant),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.importFromLrclib(track)
                                            showLrclibDialog = false
                                            statusMessage = "Imported: ${track.trackName} - ${track.artistName}"
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(track.trackName, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                                            Text("${track.artistName} • ${track.albumName ?: ""}", color = Color.Gray, fontSize = 12.sp)
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(if (track.hasSynced) EmeraldAccent.copy(alpha = 0.2f) else StudioBorder)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = if (track.hasSynced) "SYNCED" else "PLAIN",
                                                color = if (track.hasSynced) EmeraldAccent else Color.LightGray,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showLrclibDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun ImportOptionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    buttonText: String,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StudioBorder)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(iconTint.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, color = Color.Gray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = iconTint.copy(alpha = 0.2f),
                    contentColor = iconTint
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag(testTag)
            ) {
                Text(buttonText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun queryFileName(resolver: android.content.ContentResolver, uri: Uri): String? {
    val cursor = resolver.query(uri, null, null, null, null) ?: return null
    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
    cursor.moveToFirst()
    val name = if (nameIndex >= 0) cursor.getString(nameIndex) else null
    cursor.close()
    return name
}
