package com.example.ui.preview

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.LyricLine
import com.example.domain.model.LyricWord
import com.example.domain.model.Project
import com.example.domain.model.Singer
import com.example.domain.model.TimeUtils
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioSurface
import com.example.ui.viewmodel.ProjectViewModel

@Composable
fun PreviewScreen(
    viewModel: ProjectViewModel,
    modifier: Modifier = Modifier
) {
    val project by viewModel.project.collectAsState()
    val audioState by viewModel.audioEngine.audioState.collectAsState()

    var showTranslation by remember { mutableStateOf(true) }
    var fontSizeMultiplier by remember { mutableStateOf(1.0f) }

    val listState = rememberLazyListState()

    // Find currently active line
    val currentPosition = audioState.positionMs
    val activeLineIndex = remember(project.lines, currentPosition) {
        project.lines.indexOfFirst { line ->
            currentPosition in line.beginMs..line.endMs
        }.let { idx ->
            if (idx >= 0) idx
            else {
                // If in between lines, find next upcoming line or last passed line
                project.lines.indexOfLast { it.beginMs <= currentPosition }
            }
        }
    }

    // Smoothly scroll to keep active line in view without jarring jumps
    LaunchedEffect(activeLineIndex) {
        if (activeLineIndex >= 0) {
            val targetScroll = (activeLineIndex - 2).coerceAtLeast(0)
            listState.animateScrollToItem(targetScroll)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        StudioObsidian,
                        Color(0xFF131722),
                        StudioObsidian
                    )
                )
            )
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // TOP BAR: Song title & view options
            Surface(
                color = StudioSurface.copy(alpha = 0.9f),
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = project.metadata.title,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = project.metadata.artist,
                            color = Color.Gray,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = showTranslation,
                            onClick = { showTranslation = !showTranslation },
                            label = { Text("Translation", fontSize = 11.sp) },
                            leadingIcon = { Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(14.dp)) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanAccent.copy(alpha = 0.25f),
                                selectedLabelColor = CyanAccent
                            )
                        )

                        IconButton(
                            onClick = {
                                fontSizeMultiplier = when (fontSizeMultiplier) {
                                    1.0f -> 1.25f
                                    1.25f -> 1.5f
                                    else -> 1.0f
                                }
                            }
                        ) {
                            Icon(Icons.Default.FormatSize, contentDescription = "Font Size", tint = Color.LightGray)
                        }
                    }
                }
            }

            // FULLSCREEN LYRICS SCROLLER
            if (project.lines.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No lyrics loaded. Go to Import to start.",
                        color = Color.Gray,
                        fontSize = 15.sp
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(28.dp)
                ) {
                    itemsIndexed(project.lines) { index, line ->
                        val isActive = index == activeLineIndex
                        val singer = project.singers.find { it.id == line.singerId } ?: Singer.DefaultV1

                        AppleMusicLyricLineItem(
                            line = line,
                            singer = singer,
                            isActive = isActive,
                            currentPositionMs = currentPosition,
                            showTranslation = showTranslation,
                            fontSizeMultiplier = fontSizeMultiplier,
                            onLineClicked = { viewModel.audioEngine.seekTo(line.beginMs) }
                        )
                    }
                }
            }

            // BOTTOM MINI PLAYER & SYNCHRONIZED SCRUBBER
            PreviewBottomPlayer(
                audioState = audioState,
                durationMs = if (audioState.durationMs > 0) audioState.durationMs else project.metadata.durationMs,
                onPlayPause = { viewModel.audioEngine.togglePlayPause() },
                onSeek = { viewModel.audioEngine.seekTo(it) }
            )
        }
    }
}

@Composable
private fun AppleMusicLyricLineItem(
    line: LyricLine,
    singer: Singer,
    isActive: Boolean,
    currentPositionMs: Long,
    showTranslation: Boolean,
    fontSizeMultiplier: Float,
    onLineClicked: () -> Unit
) {
    val singerColor = Color(singer.colorArgb)
    val animatedAlpha by animateFloatAsState(
        targetValue = if (isActive) 1.0f else 0.35f,
        animationSpec = tween(durationMillis = 350)
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(animatedAlpha)
            .clickable { onLineClicked() }
            .padding(vertical = 4.dp),
        horizontalAlignment = if (line.isBackground) Alignment.End else Alignment.Start
    ) {
        // Singer badge (for duets or background vocals)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(singerColor)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = singer.name,
                color = singerColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            if (line.isBackground) {
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "(BG / Ad-lib)",
                    color = AmberAccent,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Word-level karaoke display
        if (line.words.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = if (line.isBackground) Arrangement.End else Arrangement.Start
            ) {
                // Render words with synchronized highlight
                val baseFontSize = (22f * fontSizeMultiplier).sp
                line.words.forEachIndexed { _, word ->
                    val isWordPast = currentPositionMs >= word.endMs
                    val isWordActive = currentPositionMs in word.beginMs..word.endMs

                    val wordColor = when {
                        !isActive -> Color.LightGray
                        isWordActive -> CyanAccent
                        isWordPast -> Color.White
                        else -> Color.Gray
                    }

                    val wordWeight = if (isWordActive) FontWeight.ExtraBold else FontWeight.Bold

                    Text(
                        text = "${word.text} ",
                        color = wordColor,
                        fontSize = baseFontSize,
                        fontWeight = wordWeight,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            }
        } else {
            Text(
                text = line.plainText,
                color = if (isActive) Color.White else Color.Gray,
                fontSize = (22f * fontSizeMultiplier).sp,
                fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Bold
            )
        }

        // Subtitle Translation (if available and enabled)
        if (showTranslation && !line.translation.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = line.translation,
                color = if (isActive) CyanAccent.copy(alpha = 0.85f) else Color.DarkGray,
                fontSize = (14f * fontSizeMultiplier).sp,
                fontWeight = FontWeight.Normal
            )
        }
    }
}

@Composable
private fun PreviewBottomPlayer(
    audioState: com.example.audio.AudioState,
    durationMs: Long,
    onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit
) {
    Surface(
        color = StudioSurface,
        tonalElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Scrubber Slider
            val maxSlider = durationMs.coerceAtLeast(1000L).toFloat()
            val currentPos = audioState.positionMs.toFloat().coerceIn(0f, maxSlider)

            Slider(
                value = currentPos,
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..maxSlider,
                colors = SliderDefaults.colors(
                    thumbColor = CyanAccent,
                    activeTrackColor = CyanAccent,
                    inactiveTrackColor = StudioBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("preview_scrubber_slider")
            )

            // Transport Row & Timestamps
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = TimeUtils.formatDisplayTime(audioState.positionMs),
                    color = CyanAccent,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    IconButton(
                        onClick = { onSeek(0L) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = "Restart", tint = Color.LightGray)
                    }

                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(CyanAccent)
                            .clickable { onPlayPause() }
                            .testTag("preview_play_pause_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (audioState.isPlaying) "Pause" else "Play",
                            tint = StudioObsidian,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Text(
                    text = TimeUtils.formatDisplayTime(durationMs),
                    color = Color.Gray,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
