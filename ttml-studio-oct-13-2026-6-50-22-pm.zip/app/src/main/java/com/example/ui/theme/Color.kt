package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Studio Slate Backgrounds
val StudioObsidian = Color(0xFF0B0D13)
val StudioSurface = Color(0xFF131620)
val StudioSurfaceVariant = Color(0xFF1C202C)
val StudioSurfaceCard = Color(0xFF181C26)
val StudioBorder = Color(0xFF262C3D)
val StudioGridLine = Color(0xFF1F2433)

// Glowing Accents & Primary Tokens
val CyanAccent = Color(0xFF00E5FF)
val CyanAccentDark = Color(0xFF00B4D8)
val AmberAccent = Color(0xFFFFB300)
val PurpleAccent = Color(0xFFA855F7)
val EmeraldAccent = Color(0xFF10B981)
val RoseAccent = Color(0xFFF43F5E)

// Text tokens
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Singer / Voice Lanes
val SingerV1Color = Color(0xFF8B5CF6) // Violet / Lead
val SingerV2Color = Color(0xFF10B981) // Emerald / Duet
val SingerV3Color = Color(0xFFF43F5E) // Rose / Ad-lib & BG
val SingerV4Color = Color(0xFF38BDF8) // Sky
val SingerV5Color = Color(0xFFF59E0B) // Amber
