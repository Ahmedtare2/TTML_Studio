package com.example.ui.timeline

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioState
import com.example.domain.model.LyricLine
import com.example.domain.model.LyricWord
import com.example.domain.model.Project
import com.example.domain.model.Singer
import com.example.domain.model.TimeUtils
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioGridLine
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.viewmodel.ProjectViewModel
import kotlin.math.roundToInt

@Composable
fun TimelineScreen(
    viewModel: ProjectViewModel,
    modifier: Modifier = Modifier
) {
    val project by viewModel.project.collectAsState()
    val audioState by viewModel.audioEngine.audioState.collectAsState()
    val waveformData by viewModel.audioEngine.waveformData.collectAsState()
    val zoomMsPerPixel by viewModel.zoomMsPerPixel.collectAsState()
    val selectedWordIds by viewModel.selectedWordIds.collectAsState()
    val isSnapEnabled by viewModel.isSnapEnabled.collectAsState()
    val snapGuideMs by viewModel.snapGuideMs.collectAsState()
    val isTapToSyncActive by viewModel.isTapToSyncActive.collectAsState()
    val tapWordIndex by viewModel.tapToSyncWordIndex.collectAsState()
    val canUndo by viewModel.canUndo.collectAsState()
    val canRedo by viewModel.canRedo.collectAsState()

    var showSyllableDialogForWord by remember { mutableStateOf<LyricWord?>(null) }
    var showDirectTimeDialogForWord by remember { mutableStateOf<LyricWord?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StudioObsidian)
    ) {
        // TOP DAW CONTROLS HEADER
        TimelineHeaderControls(
            audioState = audioState,
            projectDurationMs = project.metadata.durationMs,
            zoomMsPerPixel = zoomMsPerPixel,
            isSnapEnabled = isSnapEnabled,
            isTapToSyncActive = isTapToSyncActive,
            canUndo = canUndo,
            canRedo = canRedo,
            onPlayPause = { viewModel.audioEngine.togglePlayPause() },
            onReturnToZero = { viewModel.audioEngine.seekTo(0L) },
            onToggleLoop = { viewModel.loopSelected() },
            onToggleSnap = { viewModel.toggleSnap() },
            onZoomIn = { viewModel.zoomIn() },
            onZoomOut = { viewModel.zoomOut() },
            onFitSong = { viewModel.fitSong() },
            onZoomChange = { viewModel.setZoom(it) },
            onSpeedChange = { viewModel.audioEngine.setPlaybackSpeed(it) },
            onUndo = { viewModel.undo() },
            onRedo = { viewModel.redo() },
            onStartTapToSync = { viewModel.startTapToSync() }
        )

        // MAIN WORKSTATION TIMELINE (Waveform, Ruler, Word Tracks)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            TimelineCanvasView(
                project = project,
                audioState = audioState,
                waveformData = waveformData,
                zoomMsPerPixel = zoomMsPerPixel,
                selectedWordIds = selectedWordIds,
                isSnapEnabled = isSnapEnabled,
                snapGuideMs = snapGuideMs,
                onSeek = { viewModel.audioEngine.seekTo(it) },
                onSelectWord = { id, multi -> viewModel.selectWord(id, multi) },
                onWordMoved = { id, newStart -> viewModel.moveWord(id, newStart) },
                onWordStartTrimmed = { id, newStart -> viewModel.setWordBoundary(id, newStartMs = newStart) },
                onWordEndTrimmed = { id, newEnd -> viewModel.setWordBoundary(id, newEndMs = newEnd) },
                onSnapGuideUpdated = { viewModel.setSnapGuide(it) }
            )

            // FLOATING TAP-TO-SYNC BAR
            if (isTapToSyncActive) {
                TapToSyncOverlay(
                    project = project,
                    currentIndex = tapWordIndex,
                    currentPositionMs = audioState.positionMs,
                    onTapWord = { viewModel.recordTapForCurrentWord() },
                    onUndoTap = { viewModel.undoLastTap() },
                    onFinish = { viewModel.stopTapToSync() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                )
            }
        }

        // BOTTOM WORD INSPECTION & PRECISION NUDGE BAR
        if (!isTapToSyncActive && selectedWordIds.isNotEmpty()) {
            val selectedWords = project.lines.flatMap { it.words }.filter { selectedWordIds.contains(it.id) }
            val firstSelectedWord = selectedWords.firstOrNull()

            TimelineInspectionPanel(
                selectedWordCount = selectedWordIds.size,
                primaryWord = firstSelectedWord,
                singers = project.singers,
                onNudge = { delta -> viewModel.nudgeSelected(delta) },
                onAssignSinger = { singerId -> viewModel.assignSingerToSelected(singerId) },
                onSplitSyllable = { word -> showSyllableDialogForWord = word },
                onEditTime = { word -> showDirectTimeDialogForWord = word },
                onDelete = { viewModel.deleteSelectedWords() },
                onClearSelection = { viewModel.clearSelection() }
            )
        }
    }

    // Syllable Split Dialog
    showSyllableDialogForWord?.let { word ->
        SyllableSplitDialog(
            word = word,
            onDismiss = { showSyllableDialogForWord = null },
            onConfirmSplit = { p1, p2 ->
                viewModel.splitWordIntoSyllables(word.id, p1, p2)
                showSyllableDialogForWord = null
            }
        )
    }

    // Direct Millisecond Edit Dialog
    showDirectTimeDialogForWord?.let { word ->
        DirectTimeEditDialog(
            word = word,
            onDismiss = { showDirectTimeDialogForWord = null },
            onConfirmTime = { start, end ->
                viewModel.setWordBoundary(word.id, newStartMs = start, newEndMs = end)
                showDirectTimeDialogForWord = null
            }
        )
    }
}

@Composable
private fun TimelineHeaderControls(
    audioState: AudioState,
    projectDurationMs: Long,
    zoomMsPerPixel: Float,
    isSnapEnabled: Boolean,
    isTapToSyncActive: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    onPlayPause: () -> Unit,
    onReturnToZero: () -> Unit,
    onToggleLoop: () -> Unit,
    onToggleSnap: () -> Unit,
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit,
    onFitSong: () -> Unit,
    onZoomChange: (Float) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onStartTapToSync: () -> Unit
) {
    Surface(
        color = StudioSurface,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Row 1: Timecode, Primary Transport & Undo/Redo
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Timecode Readout
                Column {
                    Text(
                        text = TimeUtils.formatDisplayTime(audioState.positionMs),
                        color = CyanAccent,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Total: ${TimeUtils.formatShortTime(if (audioState.durationMs > 0) audioState.durationMs else projectDurationMs)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Transport Play / Pause & RTZ
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onReturnToZero,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("rtz_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Return to 00:00",
                            tint = Color.White
                        )
                    }

                    // Large glowing Play / Pause button
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (audioState.isPlaying) AmberAccent else CyanAccent)
                            .clickable { onPlayPause() }
                            .testTag("play_pause_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (audioState.isPlaying) "Pause" else "Play",
                            tint = StudioObsidian,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Loop button
                    IconButton(
                        onClick = onToggleLoop,
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                if (audioState.isLooping) AmberAccent.copy(alpha = 0.2f) else Color.Transparent,
                                CircleShape
                            )
                            .testTag("loop_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Loop,
                            contentDescription = "Loop Selection",
                            tint = if (audioState.isLooping) AmberAccent else Color.White
                        )
                    }
                }

                // Undo / Redo & Tap-to-Sync CTA
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = onUndo,
                        enabled = canUndo,
                        modifier = Modifier.size(36.dp).testTag("undo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Undo,
                            contentDescription = "Undo",
                            tint = if (canUndo) Color.White else Color.DarkGray
                        )
                    }
                    IconButton(
                        onClick = onRedo,
                        enabled = canRedo,
                        modifier = Modifier.size(36.dp).testTag("redo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Redo,
                            contentDescription = "Redo",
                            tint = if (canRedo) Color.White else Color.DarkGray
                        )
                    }

                    Button(
                        onClick = onStartTapToSync,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isTapToSyncActive) AmberAccent else CyanAccent,
                            contentColor = StudioObsidian
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = ButtonDefaults.TextButtonContentPadding,
                        modifier = Modifier.height(36.dp).testTag("tap_to_sync_mode_button")
                    ) {
                        Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Tap Sync", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            // Row 2: Zoom Slider, Snap Toggle, Playback Rate
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Snap chip
                FilterChip(
                    selected = isSnapEnabled,
                    onClick = onToggleSnap,
                    label = { Text("Snap ${if (isSnapEnabled) "ON" else "OFF"}", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyanAccent.copy(alpha = 0.25f),
                        selectedLabelColor = CyanAccent
                    ),
                    modifier = Modifier.height(32.dp).testTag("snap_toggle_button")
                )

                // Speed buttons
                listOf(0.75f, 1.0f, 1.25f).forEach { speed ->
                    val isSelected = (audioState.playbackSpeed - speed) in -0.05f..0.05f
                    Box(
                        modifier = Modifier
                            .height(28.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) CyanAccent.copy(alpha = 0.25f) else StudioSurfaceVariant)
                            .clickable { onSpeedChange(speed) }
                            .padding(horizontal = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${speed}x",
                            fontSize = 11.sp,
                            color = if (isSelected) CyanAccent else Color.LightGray,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                Spacer(Modifier.weight(1f))

                // Zoom controls
                IconButton(onClick = onZoomOut, modifier = Modifier.size(32.dp).testTag("zoom_out_button")) {
                    Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color.LightGray)
                }

                Slider(
                    value = zoomMsPerPixel,
                    onValueChange = onZoomChange,
                    valueRange = 3f..45f,
                    colors = SliderDefaults.colors(
                        thumbColor = CyanAccent,
                        activeTrackColor = CyanAccent,
                        inactiveTrackColor = StudioBorder
                    ),
                    modifier = Modifier.width(100.dp).testTag("zoom_slider")
                )

                IconButton(onClick = onZoomIn, modifier = Modifier.size(32.dp).testTag("zoom_in_button")) {
                    Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color.LightGray)
                }

                IconButton(onClick = onFitSong, modifier = Modifier.size(32.dp).testTag("fit_song_button")) {
                    Icon(Icons.Default.FitScreen, contentDescription = "Fit Song", tint = Color.LightGray)
                }
            }
        }
    }
}

@Composable
private fun TimelineCanvasView(
    project: Project,
    audioState: AudioState,
    waveformData: List<Float>,
    zoomMsPerPixel: Float,
    selectedWordIds: Set<String>,
    isSnapEnabled: Boolean,
    snapGuideMs: Long?,
    onSeek: (Long) -> Unit,
    onSelectWord: (String, Boolean) -> Unit,
    onWordMoved: (String, Long) -> Unit,
    onWordStartTrimmed: (String, Long) -> Unit,
    onWordEndTrimmed: (String, Long) -> Unit,
    onSnapGuideUpdated: (Long?) -> Unit
) {
    val scrollState = rememberScrollState()
    val maxTimelineMs = (project.lines.maxOfOrNull { it.endMs } ?: 180000L).coerceAtLeast(audioState.durationMs)
    val totalWidthPx = (maxTimelineMs / zoomMsPerPixel).coerceAtLeast(1500f)

    // Auto-scroll to follow playhead smoothly during playback
    LaunchedEffect(audioState.isPlaying, audioState.positionMs) {
        if (audioState.isPlaying) {
            val playheadPx = (audioState.positionMs / zoomMsPerPixel).roundToInt()
            val viewportWidth = scrollState.viewportSize
            if (playheadPx > scrollState.value + viewportWidth - 200 || playheadPx < scrollState.value) {
                scrollState.animateScrollTo((playheadPx - viewportWidth / 3).coerceAtLeast(0))
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .horizontalScroll(scrollState)
            .width(totalWidthPx.dp)
            .background(StudioObsidian)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // TIME RULER (Top 36dp)
            TimeRulerHeader(
                totalWidthPx = totalWidthPx,
                zoomMsPerPixel = zoomMsPerPixel,
                maxDurationMs = maxTimelineMs,
                onSeek = onSeek
            )

            // WAVEFORM TRACK (Height 70dp)
            WaveformLane(
                waveformData = waveformData,
                totalWidthPx = totalWidthPx,
                playheadMs = audioState.positionMs,
                zoomMsPerPixel = zoomMsPerPixel
            )

            Divider(color = StudioBorder, thickness = 1.dp)

            // WORD TRACKS PER LINE
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (project.lines.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No lyrics loaded. Tap 'Import' or 'Tap Sync' to begin.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    project.lines.forEach { line ->
                        LyricLineRow(
                            line = line,
                            singers = project.singers,
                            zoomMsPerPixel = zoomMsPerPixel,
                            selectedWordIds = selectedWordIds,
                            isSnapEnabled = isSnapEnabled,
                            allLines = project.lines,
                            playheadMs = audioState.positionMs,
                            onSelectWord = onSelectWord,
                            onWordMoved = onWordMoved,
                            onWordStartTrimmed = onWordStartTrimmed,
                            onWordEndTrimmed = onWordEndTrimmed,
                            onSnapGuideUpdated = onSnapGuideUpdated
                        )
                    }
                }
            }
        }

        // SNAP GUIDE VERTICAL LINE
        snapGuideMs?.let { guideMs ->
            val guideX = (guideMs / zoomMsPerPixel).dp
            Box(
                modifier = Modifier
                    .offset(x = guideX)
                    .fillMaxHeight()
                    .width(1.5.dp)
                    .background(AmberAccent)
            )
        }

        // VERTICAL PLAYHEAD
        val playheadX = (audioState.positionMs / zoomMsPerPixel).dp
        PlayheadOverlay(
            offsetX = playheadX,
            onScrub = { deltaPx ->
                val deltaMs = (deltaPx * zoomMsPerPixel).toLong()
                onSeek((audioState.positionMs + deltaMs).coerceAtLeast(0L))
            }
        )
    }
}

@Composable
private fun TimeRulerHeader(
    totalWidthPx: Float,
    zoomMsPerPixel: Float,
    maxDurationMs: Long,
    onSeek: (Long) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(34.dp)
            .background(StudioSurface)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val clickedMs = (offset.x * zoomMsPerPixel).toLong()
                    onSeek(clickedMs.coerceIn(0L, maxDurationMs))
                }
            }
            .drawBehind {
                val stepMs = if (zoomMsPerPixel < 10f) 1000L else if (zoomMsPerPixel < 25f) 2000L else 5000L
                val maxMs = (totalWidthPx * zoomMsPerPixel).toLong()

                var t = 0L
                while (t <= maxMs) {
                    val x = t / zoomMsPerPixel
                    val isMajor = (t % (stepMs * 2) == 0L)
                    val lineH = if (isMajor) 18f else 10f

                    drawLine(
                        color = if (isMajor) Color.LightGray else StudioBorder,
                        start = Offset(x, size.height - lineH),
                        end = Offset(x, size.height),
                        strokeWidth = if (isMajor) 1.5f else 1f
                    )
                    t += stepMs
                }
            }
    ) {
        // Display timestamp labels on major intervals
        val stepMs = if (zoomMsPerPixel < 10f) 2000L else if (zoomMsPerPixel < 25f) 5000L else 10000L
        var t = 0L
        while (t <= maxDurationMs) {
            val labelX = (t / zoomMsPerPixel).dp
            Text(
                text = TimeUtils.formatShortTime(t),
                color = Color.LightGray,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .offset(x = labelX + 3.dp, y = 2.dp)
            )
            t += stepMs
        }
    }
}

@Composable
private fun WaveformLane(
    waveformData: List<Float>,
    totalWidthPx: Float,
    playheadMs: Long,
    zoomMsPerPixel: Float
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(StudioSurfaceVariant.copy(alpha = 0.5f))
            .drawBehind {
                if (waveformData.isEmpty()) return@drawBehind
                val totalBars = waveformData.size
                val barWidth = totalWidthPx / totalBars.toFloat()
                val playheadPx = playheadMs / zoomMsPerPixel

                waveformData.forEachIndexed { i, amp ->
                    val x = i * barWidth
                    val barH = size.height * amp * 0.85f
                    val y = (size.height - barH) / 2f
                    val isPast = x <= playheadPx

                    drawRect(
                        color = if (isPast) CyanAccent.copy(alpha = 0.7f) else Color(0xFF334155),
                        topLeft = Offset(x, y),
                        size = Size((barWidth * 0.75f).coerceAtLeast(1.5f), barH)
                    )
                }
            }
    )
}

@Composable
private fun LyricLineRow(
    line: LyricLine,
    singers: List<Singer>,
    zoomMsPerPixel: Float,
    selectedWordIds: Set<String>,
    isSnapEnabled: Boolean,
    allLines: List<LyricLine>,
    playheadMs: Long,
    onSelectWord: (String, Boolean) -> Unit,
    onWordMoved: (String, Long) -> Unit,
    onWordStartTrimmed: (String, Long) -> Unit,
    onWordEndTrimmed: (String, Long) -> Unit,
    onSnapGuideUpdated: (Long?) -> Unit
) {
    val singer = singers.find { it.id == line.singerId } ?: Singer.DefaultV1
    val singerColor = Color(singer.colorArgb)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(StudioSurfaceVariant.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
    ) {
        // Words in this line
        line.words.forEach { word ->
            val isSelected = selectedWordIds.contains(word.id)
            val wordSinger = if (word.singerId != null && word.singerId != line.singerId) {
                singers.find { it.id == word.singerId }?.colorArgb?.let { Color(it) } ?: singerColor
            } else singerColor

            WordBlock(
                word = word,
                color = wordSinger,
                zoomMsPerPixel = zoomMsPerPixel,
                isSelected = isSelected,
                isSnapEnabled = isSnapEnabled,
                allLines = allLines,
                playheadMs = playheadMs,
                onSelect = { multi -> onSelectWord(word.id, multi) },
                onMoved = { newStart -> onWordMoved(word.id, newStart) },
                onStartTrimmed = { newStart -> onWordStartTrimmed(word.id, newStart) },
                onEndTrimmed = { newEnd -> onWordEndTrimmed(word.id, newEnd) },
                onSnapGuideUpdated = onSnapGuideUpdated
            )
        }
    }
}

@Composable
private fun WordBlock(
    word: LyricWord,
    color: Color,
    zoomMsPerPixel: Float,
    isSelected: Boolean,
    isSnapEnabled: Boolean,
    allLines: List<LyricLine>,
    playheadMs: Long,
    onSelect: (Boolean) -> Unit,
    onMoved: (Long) -> Unit,
    onStartTrimmed: (Long) -> Unit,
    onEndTrimmed: (Long) -> Unit,
    onSnapGuideUpdated: (Long?) -> Unit
) {
    val startPx = (word.beginMs / zoomMsPerPixel)
    val widthPx = ((word.endMs - word.beginMs) / zoomMsPerPixel).coerceAtLeast(32f)

    var dragOffsetX by remember { mutableFloatStateOf(0f) }

    // Nearby snap target calculator
    fun calculateSnappedTime(candidateMs: Long): Long {
        if (!isSnapEnabled) return candidateMs
        val snapThresholdMs = (15f * zoomMsPerPixel).toLong() // 15px snap window

        // Check playhead
        if (kotlin.math.abs(candidateMs - playheadMs) <= snapThresholdMs) {
            onSnapGuideUpdated(playheadMs)
            return playheadMs
        }

        // Check word boundaries
        for (l in allLines) {
            for (w in l.words) {
                if (w.id == word.id) continue
                if (kotlin.math.abs(candidateMs - w.beginMs) <= snapThresholdMs) {
                    onSnapGuideUpdated(w.beginMs)
                    return w.beginMs
                }
                if (kotlin.math.abs(candidateMs - w.endMs) <= snapThresholdMs) {
                    onSnapGuideUpdated(w.endMs)
                    return w.endMs
                }
            }
        }
        onSnapGuideUpdated(null)
        return candidateMs
    }

    Box(
        modifier = Modifier
            .offset { IntOffset((startPx + dragOffsetX).roundToInt(), 0) }
            .width(widthPx.dp)
            .height(44.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = if (isSelected) 0.9f else 0.45f))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) AmberAccent else color,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable { onSelect(false) }
            .pointerInput(word.id) {
                detectDragGestures(
                    onDragStart = { onSelect(false) },
                    onDragEnd = {
                        val deltaMs = (dragOffsetX * zoomMsPerPixel).toLong()
                        val newCandidate = (word.beginMs + deltaMs).coerceAtLeast(0L)
                        val snapped = calculateSnappedTime(newCandidate)
                        onMoved(snapped)
                        dragOffsetX = 0f
                        onSnapGuideUpdated(null)
                    },
                    onDragCancel = {
                        dragOffsetX = 0f
                        onSnapGuideUpdated(null)
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragOffsetX += dragAmount.x
                        val tempCandidate = (word.beginMs + (dragOffsetX * zoomMsPerPixel).toLong()).coerceAtLeast(0L)
                        calculateSnappedTime(tempCandidate)
                    }
                )
            }
    ) {
        // LEFT TRIM HANDLE
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .width(14.dp)
                .fillMaxHeight()
                .background(Color.White.copy(alpha = 0.2f))
                .pointerInput(word.id) {
                    detectDragGestures(
                        onDragEnd = { onSnapGuideUpdated(null) },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val deltaMs = (dragAmount.x * zoomMsPerPixel).toLong()
                            val newStart = (word.beginMs + deltaMs).coerceAtLeast(0L)
                            val snapped = calculateSnappedTime(newStart)
                            if (snapped < word.endMs - 30L) {
                                onStartTrimmed(snapped)
                            }
                        }
                    )
                }
        )

        // WORD TEXT LABEL
        Text(
            text = word.text,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 14.dp)
        )

        // RIGHT TRIM HANDLE
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(14.dp)
                .fillMaxHeight()
                .background(Color.White.copy(alpha = 0.2f))
                .pointerInput(word.id) {
                    detectDragGestures(
                        onDragEnd = { onSnapGuideUpdated(null) },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val deltaMs = (dragAmount.x * zoomMsPerPixel).toLong()
                            val newEnd = word.endMs + deltaMs
                            val snapped = calculateSnappedTime(newEnd)
                            if (snapped > word.beginMs + 30L) {
                                onEndTrimmed(snapped)
                            }
                        }
                    )
                }
        )
    }
}

@Composable
private fun PlayheadOverlay(
    offsetX: androidx.compose.ui.unit.Dp,
    onScrub: (Float) -> Unit
) {
    Box(
        modifier = Modifier
            .offset(x = offsetX - 12.dp)
            .fillMaxHeight()
            .width(24.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onScrub(dragAmount.x)
                }
            }
    ) {
        // Glowing triangle cursor cap
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .size(16.dp)
                .drawBehind {
                    val path = Path().apply {
                        moveTo(0f, 0f)
                        lineTo(size.width, 0f)
                        lineTo(size.width / 2f, size.height)
                        close()
                    }
                    drawPath(path, CyanAccent)
                }
        )

        // Vertical laser playhead line
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 14.dp)
                .fillMaxHeight()
                .width(2.dp)
                .background(CyanAccent)
        )
    }
}

@Composable
private fun TapToSyncOverlay(
    project: Project,
    currentIndex: Int,
    currentPositionMs: Long,
    onTapWord: () -> Unit,
    onUndoTap: () -> Unit,
    onFinish: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allWords = remember(project) { project.lines.flatMap { it.words } }
    val currentWord = allWords.getOrNull(currentIndex)
    val nextWord = allWords.getOrNull(currentIndex + 1)

    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AmberAccent)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tap-To-Sync Mode",
                    color = AmberAccent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Word ${currentIndex + 1} of ${allWords.size}",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(Modifier.height(8.dp))

            // Current Word Display
            Text(
                text = currentWord?.text ?: "All words synchronized!",
                color = CyanAccent,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            if (nextWord != null) {
                Text(
                    text = "Up next: ${nextWord.text}",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }

            Spacer(Modifier.height(16.dp))

            // Big Tap Action Button
            Button(
                onClick = onTapWord,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberAccent,
                    contentColor = StudioObsidian
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("tap_sync_action_button")
            ) {
                Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(8.dp))
                Text("TAP CURRENT WORD", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedButton(
                    onClick = onUndoTap,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.testTag("undo_tap_button")
                ) {
                    Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Undo Last Tap")
                }

                Button(
                    onClick = onFinish,
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = StudioObsidian),
                    modifier = Modifier.testTag("finish_tap_button")
                ) {
                    Text("Done")
                }
            }
        }
    }
}

@Composable
private fun TimelineInspectionPanel(
    selectedWordCount: Int,
    primaryWord: LyricWord?,
    singers: List<Singer>,
    onNudge: (Long) -> Unit,
    onAssignSinger: (String) -> Unit,
    onSplitSyllable: (LyricWord) -> Unit,
    onEditTime: (LyricWord) -> Unit,
    onDelete: () -> Unit,
    onClearSelection: () -> Unit
) {
    Surface(
        color = StudioSurface,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Header Info & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (selectedWordCount == 1 && primaryWord != null) {
                        "Word: \"${primaryWord.text}\" [${TimeUtils.formatDisplayTime(primaryWord.beginMs)} - ${TimeUtils.formatDisplayTime(primaryWord.endMs)}]"
                    } else "$selectedWordCount words selected",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Row {
                    if (primaryWord != null && selectedWordCount == 1) {
                        IconButton(onClick = { onEditTime(primaryWord) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Add, contentDescription = "Manual Time", tint = CyanAccent)
                        }
                        IconButton(onClick = { onSplitSyllable(primaryWord) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.CallSplit, contentDescription = "Split Syllable", tint = AmberAccent)
                        }
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp).testTag("delete_word_button")) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                    }
                    TextButton(onClick = onClearSelection, modifier = Modifier.height(32.dp)) {
                        Text("Deselect", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            // Row 2: Micro-Nudge buttons & Singer Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Nudge buttons
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(-50L, -10L, 10L, 50L).forEach { delta ->
                        Box(
                            modifier = Modifier
                                .height(30.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(StudioSurfaceVariant)
                                .clickable { onNudge(delta) }
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${if (delta > 0) "+" else ""}${delta}ms",
                                color = if (delta > 0) CyanAccent else AmberAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Singer selector chips
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    singers.forEach { singer ->
                        val color = Color(singer.colorArgb)
                        Box(
                            modifier = Modifier
                                .height(30.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(color.copy(alpha = 0.25f))
                                .border(1.dp, color, RoundedCornerShape(6.dp))
                                .clickable { onAssignSinger(singer.id) }
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = singer.id.uppercase(),
                                color = color,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SyllableSplitDialog(
    word: LyricWord,
    onDismiss: () -> Unit,
    onConfirmSplit: (String, String) -> Unit
) {
    var part1 by remember { mutableStateOf(word.text.take(word.text.length / 2)) }
    var part2 by remember { mutableStateOf(word.text.drop(word.text.length / 2)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Split Word into Syllables") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Split \"${word.text}\" into two timed syllables:")
                OutlinedTextField(
                    value = part1,
                    onValueChange = { part1 = it },
                    label = { Text("First Syllable") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = part2,
                    onValueChange = { part2 = it },
                    label = { Text("Second Syllable") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmSplit(part1, part2) },
                enabled = part1.isNotBlank() && part2.isNotBlank()
            ) {
                Text("Split")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun DirectTimeEditDialog(
    word: LyricWord,
    onDismiss: () -> Unit,
    onConfirmTime: (Long, Long) -> Unit
) {
    var startInput by remember { mutableStateOf(word.beginMs.toString()) }
    var endInput by remember { mutableStateOf(word.endMs.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Manual Millisecond Timing") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Word: \"${word.text}\"")
                OutlinedTextField(
                    value = startInput,
                    onValueChange = { startInput = it },
                    label = { Text("Start Timestamp (ms)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = endInput,
                    onValueChange = { endInput = it },
                    label = { Text("End Timestamp (ms)") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val s = startInput.toLongOrNull() ?: word.beginMs
                    val e = endInput.toLongOrNull() ?: word.endMs
                    onConfirmTime(s, e)
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
