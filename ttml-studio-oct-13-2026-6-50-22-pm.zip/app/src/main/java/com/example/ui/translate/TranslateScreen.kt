package com.example.ui.translate

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TimeUtils
import com.example.domain.translate.ArabicTransliterationStyle
import com.example.domain.translate.PhoneticEngine
import com.example.domain.translate.TargetLanguage
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioObsidian
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceCard
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.viewmodel.ProjectViewModel

@Composable
fun TranslateScreen(
    viewModel: ProjectViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val project by viewModel.project.collectAsState()
    val isTranslating by viewModel.isTranslating.collectAsState()
    val translationError by viewModel.translationError.collectAsState()

    var selectedLang by remember { mutableStateOf(TargetLanguage.ALL.first()) }
    var langMenuExpanded by remember { mutableStateOf(false) }

    var arabicStyle by remember { mutableStateOf(ArabicTransliterationStyle.ALA_LC) }
    var arabicStyleMenuExpanded by remember { mutableStateOf(false) }

    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied $label to clipboard", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StudioObsidian)
    ) {
        // TOP CONTROL HEADER
        Surface(
            color = StudioSurface,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Translation & Pronunciation",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Synchronized lines linked with phonetic transliterations",
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )
                    }

                    // Language Dropdown selector
                    Box {
                        OutlinedButton(
                            onClick = { langMenuExpanded = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanAccent),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("${selectedLang.flag} ${selectedLang.name}")
                        }

                        DropdownMenu(
                            expanded = langMenuExpanded,
                            onDismissRequest = { langMenuExpanded = false }
                        ) {
                            TargetLanguage.ALL.forEach { lang ->
                                DropdownMenuItem(
                                    text = { Text("${lang.flag} ${lang.name}") },
                                    onClick = {
                                        selectedLang = lang
                                        langMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Action Bar: AI Translate & Auto Pronunciations
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { viewModel.translateProject(selectedLang) },
                        enabled = !isTranslating && project.lines.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = StudioObsidian),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("translate_all_button")
                    ) {
                        if (isTranslating) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = StudioObsidian)
                            Spacer(Modifier.width(8.dp))
                            Text("Translating...")
                        } else {
                            Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Translate with AI", fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = { viewModel.autoGeneratePronunciations() },
                        enabled = project.lines.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = AmberAccent, contentColor = StudioObsidian),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("auto_phonetics_button")
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Auto Phonetics", fontWeight = FontWeight.Bold)
                    }
                }

                // Arabic Script Transliteration Options
                val hasArabic = remember(project) {
                    project.lines.any { PhoneticEngine.isArabic(it.plainText) }
                }

                if (hasArabic) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Arabic Transliteration Style:",
                            color = AmberAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Box {
                            TextButton(onClick = { arabicStyleMenuExpanded = true }) {
                                Text(arabicStyle.displayName, color = CyanAccent, fontSize = 12.sp)
                            }
                            DropdownMenu(
                                expanded = arabicStyleMenuExpanded,
                                onDismissRequest = { arabicStyleMenuExpanded = false }
                            ) {
                                ArabicTransliterationStyle.values().forEach { style ->
                                    DropdownMenuItem(
                                        text = { Text(style.displayName) },
                                        onClick = {
                                            arabicStyle = style
                                            arabicStyleMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                translationError?.let { err ->
                    Spacer(Modifier.height(6.dp))
                    Text(err, color = Color.Red, fontSize = 12.sp)
                }
            }
        }

        // SYNCED LINES LIST
        if (project.lines.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No lyric lines to translate. Import lyrics first.",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(project.lines) { index, line ->
                    SyncedLineTranslationCard(
                        lineIndex = index + 1,
                        line = line,
                        onTranslationChanged = { viewModel.updateLineTranslation(line.id, it) },
                        onPronunciationChanged = { viewModel.updateLinePronunciation(line.id, it) },
                        onCopyOriginal = { copyToClipboard("Original Line ${index + 1}", line.plainText) },
                        onCopyTranslation = { line.translation?.let { copyToClipboard("Translation", it) } },
                        onCopyPronunciation = { line.pronunciation?.let { copyToClipboard("Pronunciation", it) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun SyncedLineTranslationCard(
    lineIndex: Int,
    line: com.example.domain.model.LyricLine,
    onTranslationChanged: (String) -> Unit,
    onPronunciationChanged: (String) -> Unit,
    onCopyOriginal: () -> Unit,
    onCopyTranslation: () -> Unit,
    onCopyPronunciation: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceCard),
        shape = RoundedCornerShape(10.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(StudioBorder)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Line Header & Timestamps
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(CyanAccent.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "#$lineIndex",
                            color = CyanAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "${TimeUtils.formatDisplayTime(line.beginMs)} - ${TimeUtils.formatDisplayTime(line.endMs)}",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(onClick = onCopyOriginal, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy line", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                }
            }

            Spacer(Modifier.height(8.dp))

            // Original Source Text
            Text(
                text = line.plainText.ifEmpty { "(Empty line)" },
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(Modifier.height(10.dp))

            // Translation Field
            var translationInput by remember(line.translation) { mutableStateOf(line.translation ?: "") }
            OutlinedTextField(
                value = translationInput,
                onValueChange = {
                    translationInput = it
                    onTranslationChanged(it)
                },
                label = { Text("Translation", fontSize = 11.sp) },
                placeholder = { Text("Enter or AI-generate translation...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            // Phonetic Pronunciation Field
            var pronunciationInput by remember(line.pronunciation) { mutableStateOf(line.pronunciation ?: "") }
            OutlinedTextField(
                value = pronunciationInput,
                onValueChange = {
                    pronunciationInput = it
                    onPronunciationChanged(it)
                },
                label = { Text("Phonetic Pronunciation (IPA / Transliteration)", fontSize = 11.sp) },
                placeholder = { Text("e.g. /ˈstɑːlaɪt ˈfɔːlɪŋ/...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
