package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioEngine
import com.example.audio.AudioState
import com.example.data.local.AppDatabase
import com.example.data.local.ProjectRepository
import com.example.data.remote.lrclib.LrclibClient
import com.example.data.remote.lrclib.LrclibTrack
import com.example.domain.demo.DemoProjectProvider
import com.example.domain.model.LyricLine
import com.example.domain.model.LyricWord
import com.example.domain.model.Project
import com.example.domain.model.Singer
import com.example.domain.model.SongMetadata
import com.example.domain.parsers.LrcParser
import com.example.domain.parsers.SrtParser
import com.example.domain.parsers.TxtParser
import com.example.domain.translate.GeminiTranslationService
import com.example.domain.translate.PhoneticEngine
import com.example.domain.translate.TargetLanguage
import com.example.domain.ttml.TtmlParser
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class ProjectViewModel(application: Application) : AndroidViewModel(application) {

    val audioEngine = AudioEngine(application)
    private val repository: ProjectRepository

    private val _project = MutableStateFlow(
        Project(
            metadata = SongMetadata(title = "New Project", artist = "Artist"),
            lines = emptyList()
        )
    )
    val project: StateFlow<Project> = _project.asStateFlow()

    // Undo / Redo history
    private val undoStack = ArrayDeque<Project>()
    private val redoStack = ArrayDeque<Project>()
    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()
    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    // Timeline interactive state
    private val _zoomMsPerPixel = MutableStateFlow(12.0f) // zoom level (lower = zoomed in)
    val zoomMsPerPixel: StateFlow<Float> = _zoomMsPerPixel.asStateFlow()

    private val _selectedWordIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedWordIds: StateFlow<Set<String>> = _selectedWordIds.asStateFlow()

    private val _selectedLineId = MutableStateFlow<String?>(null)
    val selectedLineId: StateFlow<String?> = _selectedLineId.asStateFlow()

    private val _isSnapEnabled = MutableStateFlow(true)
    val isSnapEnabled: StateFlow<Boolean> = _isSnapEnabled.asStateFlow()

    private val _snapGuideMs = MutableStateFlow<Long?>(null)
    val snapGuideMs: StateFlow<Long?> = _snapGuideMs.asStateFlow()

    // Tap-to-sync state
    private val _isTapToSyncActive = MutableStateFlow(false)
    val isTapToSyncActive: StateFlow<Boolean> = _isTapToSyncActive.asStateFlow()

    private val _tapToSyncWordIndex = MutableStateFlow(0)
    val tapToSyncWordIndex: StateFlow<Int> = _tapToSyncWordIndex.asStateFlow()

    private val tapHistory = mutableListOf<Triple<String, Long, Long>>() // wordId, oldStart, oldEnd

    // Search state
    private val _searchResults = MutableStateFlow<List<LrclibTrack>>(emptyList())
    val searchResults: StateFlow<List<LrclibTrack>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchError = MutableStateFlow<String?>(null)
    val searchError: StateFlow<String?> = _searchError.asStateFlow()

    // Translation state
    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    private val _translationError = MutableStateFlow<String?>(null)
    val translationError: StateFlow<String?> = _translationError.asStateFlow()

    // Auto-save debouncer
    private var autoSaveJob: Job? = null

    val savedProjects: StateFlow<List<Project>>

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ProjectRepository(db.projectDao())
        savedProjects = repository.getProjectsFlow().stateIn(
            viewModelScope,
            SharingStarted.Lazily,
            emptyList()
        )

        // Generate default waveform
        audioEngine.generateWaveform("default_seed")
    }

    private fun pushUndoState() {
        undoStack.addLast(_project.value)
        if (undoStack.size > 50) undoStack.removeFirst()
        redoStack.clear()
        _canUndo.value = true
        _canRedo.value = false
        triggerAutoSave()
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            redoStack.addLast(_project.value)
            _project.value = undoStack.removeLast()
            _canUndo.value = undoStack.isNotEmpty()
            _canRedo.value = true
            triggerAutoSave()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            undoStack.addLast(_project.value)
            _project.value = redoStack.removeLast()
            _canUndo.value = true
            _canRedo.value = redoStack.isNotEmpty()
            triggerAutoSave()
        }
    }

    private fun triggerAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(1000)
            repository.saveProject(_project.value)
        }
    }

    fun setZoom(msPerPixel: Float) {
        _zoomMsPerPixel.value = msPerPixel.coerceIn(2.0f, 60.0f)
    }

    fun zoomIn() {
        setZoom(_zoomMsPerPixel.value * 0.75f)
    }

    fun zoomOut() {
        setZoom(_zoomMsPerPixel.value * 1.33f)
    }

    fun fitSong() {
        val dur = _project.value.metadata.durationMs.coerceAtLeast(10000L)
        // Assume typical viewport width around 360dp
        setZoom((dur.toFloat() / 360f).coerceIn(2f, 80f))
    }

    fun toggleSnap() {
        _isSnapEnabled.value = !_isSnapEnabled.value
    }

    fun setSnapGuide(timeMs: Long?) {
        _snapGuideMs.value = timeMs
    }

    fun selectWord(wordId: String, multiSelect: Boolean = false) {
        if (multiSelect) {
            val current = _selectedWordIds.value.toMutableSet()
            if (current.contains(wordId)) current.remove(wordId) else current.add(wordId)
            _selectedWordIds.value = current
        } else {
            _selectedWordIds.value = setOf(wordId)
        }
        // Update selected line
        val line = _project.value.lines.find { l -> l.words.any { it.id == wordId } }
        _selectedLineId.value = line?.id
    }

    fun clearSelection() {
        _selectedWordIds.value = emptySet()
        _selectedLineId.value = null
    }

    fun selectLine(lineId: String) {
        _selectedLineId.value = lineId
        val line = _project.value.lines.find { it.id == lineId }
        _selectedWordIds.value = line?.words?.map { it.id }?.toSet() ?: emptySet()
    }

    // --- TIMELINE WORD & LINE EDITING ---

    fun nudgeSelected(deltaMs: Long) {
        val selected = _selectedWordIds.value
        if (selected.isEmpty()) return
        pushUndoState()

        val updatedLines = _project.value.lines.map { line ->
            val updatedWords = line.words.map { word ->
                if (selected.contains(word.id)) {
                    val newStart = (word.beginMs + deltaMs).coerceAtLeast(0L)
                    val newEnd = (word.endMs + deltaMs).coerceAtLeast(newStart + 20L)
                    word.copy(beginMs = newStart, endMs = newEnd)
                } else word
            }
            val lineStart = updatedWords.firstOrNull()?.beginMs ?: line.beginMs
            val lineEnd = updatedWords.lastOrNull()?.endMs ?: line.endMs
            line.copy(words = updatedWords, beginMs = lineStart, endMs = lineEnd)
        }
        _project.value = _project.value.copy(lines = updatedLines)
    }

    fun setWordBoundary(wordId: String, newStartMs: Long? = null, newEndMs: Long? = null) {
        pushUndoState()
        val updatedLines = _project.value.lines.map { line ->
            val updatedWords = line.words.map { word ->
                if (word.id == wordId) {
                    val s = newStartMs ?: word.beginMs
                    val e = (newEndMs ?: word.endMs).coerceAtLeast(s + 20L)
                    word.copy(beginMs = s, endMs = e)
                } else word
            }
            val lineStart = updatedWords.firstOrNull()?.beginMs ?: line.beginMs
            val lineEnd = updatedWords.lastOrNull()?.endMs ?: line.endMs
            line.copy(words = updatedWords, beginMs = lineStart, endMs = lineEnd)
        }
        _project.value = _project.value.copy(lines = updatedLines)
    }

    fun moveWord(wordId: String, newStartMs: Long) {
        pushUndoState()
        val updatedLines = _project.value.lines.map { line ->
            val updatedWords = line.words.map { word ->
                if (word.id == wordId) {
                    val dur = word.durationMs
                    val s = newStartMs.coerceAtLeast(0L)
                    word.copy(beginMs = s, endMs = s + dur)
                } else word
            }
            val lineStart = updatedWords.firstOrNull()?.beginMs ?: line.beginMs
            val lineEnd = updatedWords.lastOrNull()?.endMs ?: line.endMs
            line.copy(words = updatedWords, beginMs = lineStart, endMs = lineEnd)
        }
        _project.value = _project.value.copy(lines = updatedLines)
    }

    fun assignSingerToSelected(singerId: String) {
        val selected = _selectedWordIds.value
        if (selected.isEmpty()) return
        pushUndoState()

        val updatedLines = _project.value.lines.map { line ->
            val updatedWords = line.words.map { word ->
                if (selected.contains(word.id)) word.copy(singerId = singerId) else word
            }
            // If all words in line have the same singer, update line singer too
            val allSame = updatedWords.isNotEmpty() && updatedWords.all { it.singerId == singerId }
            line.copy(words = updatedWords, singerId = if (allSame) singerId else line.singerId)
        }
        _project.value = _project.value.copy(lines = updatedLines)
    }

    fun assignSingerToLine(lineId: String, singerId: String) {
        pushUndoState()
        val updatedLines = _project.value.lines.map { line ->
            if (line.id == lineId) {
                line.copy(
                    singerId = singerId,
                    words = line.words.map { it.copy(singerId = singerId) }
                )
            } else line
        }
        _project.value = _project.value.copy(lines = updatedLines)
    }

    fun splitWordIntoSyllables(wordId: String, part1: String, part2: String) {
        pushUndoState()
        val updatedLines = _project.value.lines.map { line ->
            val wordIdx = line.words.indexOfFirst { it.id == wordId }
            if (wordIdx >= 0) {
                val orig = line.words[wordIdx]
                val midMs = orig.beginMs + (orig.durationMs / 2)
                val w1 = orig.copy(id = UUID.randomUUID().toString(), text = part1, endMs = midMs)
                val w2 = orig.copy(id = UUID.randomUUID().toString(), text = part2, beginMs = midMs)
                val mutableWords = line.words.toMutableList()
                mutableWords.removeAt(wordIdx)
                mutableWords.add(wordIdx, w2)
                mutableWords.add(wordIdx, w1)
                line.copy(words = mutableWords)
            } else line
        }
        _project.value = _project.value.copy(lines = updatedLines)
    }

    fun splitLineAtWord(lineId: String, atWordIndex: Int) {
        val lineIdx = _project.value.lines.indexOfFirst { it.id == lineId }
        if (lineIdx < 0) return
        val line = _project.value.lines[lineIdx]
        if (atWordIndex <= 0 || atWordIndex >= line.words.size) return

        pushUndoState()
        val firstWords = line.words.take(atWordIndex)
        val secondWords = line.words.drop(atWordIndex)

        val line1 = line.copy(
            id = UUID.randomUUID().toString(),
            words = firstWords,
            beginMs = firstWords.first().beginMs,
            endMs = firstWords.last().endMs
        )
        val line2 = line.copy(
            id = UUID.randomUUID().toString(),
            words = secondWords,
            beginMs = secondWords.first().beginMs,
            endMs = secondWords.last().endMs
        )

        val newLines = _project.value.lines.toMutableList()
        newLines.removeAt(lineIdx)
        newLines.add(lineIdx, line2)
        newLines.add(lineIdx, line1)
        _project.value = _project.value.copy(lines = newLines)
    }

    fun deleteSelectedWords() {
        val selected = _selectedWordIds.value
        if (selected.isEmpty()) return
        pushUndoState()

        val updatedLines = _project.value.lines.mapNotNull { line ->
            val remainingWords = line.words.filterNot { selected.contains(it.id) }
            if (remainingWords.isEmpty()) {
                null // Delete line if empty
            } else {
                line.copy(
                    words = remainingWords,
                    beginMs = remainingWords.first().beginMs,
                    endMs = remainingWords.last().endMs
                )
            }
        }
        _project.value = _project.value.copy(lines = updatedLines)
        clearSelection()
    }

    fun deleteLine(lineId: String) {
        pushUndoState()
        val updatedLines = _project.value.lines.filterNot { it.id == lineId }
        _project.value = _project.value.copy(lines = updatedLines)
        if (_selectedLineId.value == lineId) clearSelection()
    }

    fun addLine(singerId: String = "v1") {
        pushUndoState()
        val lastEnd = _project.value.lines.lastOrNull()?.endMs ?: 0L
        val start = lastEnd + 1000L
        val newLine = LyricLine(
            id = UUID.randomUUID().toString(),
            singerId = singerId,
            beginMs = start,
            endMs = start + 3000L,
            words = listOf(
                LyricWord(UUID.randomUUID().toString(), "New", start, start + 800L, singerId),
                LyricWord(UUID.randomUUID().toString(), "Line", start + 850L, start + 1800L, singerId)
            )
        )
        _project.value = _project.value.copy(lines = _project.value.lines + newLine)
    }

    fun loopSelected() {
        val selectedIds = _selectedWordIds.value
        if (selectedIds.isEmpty()) {
            val lineId = _selectedLineId.value
            val line = _project.value.lines.find { it.id == lineId }
            if (line != null) {
                audioEngine.setLoopRegion(line.beginMs, line.endMs, true)
            }
            return
        }

        val allWords = _project.value.lines.flatMap { it.words }
        val matched = allWords.filter { selectedIds.contains(it.id) }
        if (matched.isNotEmpty()) {
            val minStart = matched.minOf { it.beginMs }
            val maxEnd = matched.maxOf { it.endMs }
            audioEngine.setLoopRegion(minStart, maxEnd, true)
        }
    }

    // --- TAP-TO-SYNC MODE ---

    fun startTapToSync() {
        _isTapToSyncActive.value = true
        _tapToSyncWordIndex.value = 0
        tapHistory.clear()
        audioEngine.seekTo(0L)
        audioEngine.play()
    }

    fun recordTapForCurrentWord() {
        val allWords = _project.value.lines.flatMap { it.words }
        val idx = _tapToSyncWordIndex.value
        if (idx >= allWords.size) {
            stopTapToSync()
            return
        }

        val targetWord = allWords[idx]
        val currentPlayPos = audioEngine.audioState.value.positionMs

        tapHistory.add(Triple(targetWord.id, targetWord.beginMs, targetWord.endMs))

        // Update word start to current playhead, and end to start + 350ms (or previous word end)
        val newStart = currentPlayPos
        val newEnd = newStart + 400L

        // If not the first word, also close the previous word's end if needed
        val updatedLines = _project.value.lines.map { line ->
            val updatedWords = line.words.map { w ->
                if (w.id == targetWord.id) {
                    w.copy(beginMs = newStart, endMs = newEnd)
                } else if (idx > 0 && w.id == allWords[idx - 1].id) {
                    w.copy(endMs = newStart.coerceAtLeast(w.beginMs + 50L))
                } else w
            }
            line.copy(
                words = updatedWords,
                beginMs = updatedWords.firstOrNull()?.beginMs ?: line.beginMs,
                endMs = updatedWords.lastOrNull()?.endMs ?: line.endMs
            )
        }
        _project.value = _project.value.copy(lines = updatedLines)
        _tapToSyncWordIndex.value = idx + 1
    }

    fun undoLastTap() {
        if (tapHistory.isEmpty()) return
        val last = tapHistory.removeLast()
        val wordId = last.first
        val oldStart = last.second
        val oldEnd = last.third

        val updatedLines = _project.value.lines.map { line ->
            val updatedWords = line.words.map { w ->
                if (w.id == wordId) w.copy(beginMs = oldStart, endMs = oldEnd) else w
            }
            line.copy(
                words = updatedWords,
                beginMs = updatedWords.firstOrNull()?.beginMs ?: line.beginMs,
                endMs = updatedWords.lastOrNull()?.endMs ?: line.endMs
            )
        }
        _project.value = _project.value.copy(lines = updatedLines)
        _tapToSyncWordIndex.value = (_tapToSyncWordIndex.value - 1).coerceAtLeast(0)
    }

    fun stopTapToSync() {
        _isTapToSyncActive.value = false
        audioEngine.pause()
        triggerAutoSave()
    }

    // --- IMPORT WORKFLOWS ---

    fun loadAudio(uri: Uri, fileName: String) {
        audioEngine.loadAudio(uri, fileName)
        _project.value = _project.value.copy(
            metadata = _project.value.metadata.copy(
                audioUri = uri.toString(),
                audioFileName = fileName
            )
        )
        triggerAutoSave()
    }

    fun importTtml(xmlContent: String) {
        TtmlParser.parse(xmlContent).onSuccess { parsed ->
            pushUndoState()
            _project.value = parsed
            audioEngine.generateWaveform(parsed.metadata.title)
            triggerAutoSave()
        }
    }

    fun importLrc(lrcContent: String) {
        pushUndoState()
        val parsed = LrcParser.parse(lrcContent)
        _project.value = parsed
        audioEngine.generateWaveform(parsed.metadata.title)
        triggerAutoSave()
    }

    fun importSrt(srtContent: String) {
        pushUndoState()
        val parsed = SrtParser.parse(srtContent)
        _project.value = parsed
        audioEngine.generateWaveform(parsed.metadata.title)
        triggerAutoSave()
    }

    fun importText(plainText: String) {
        pushUndoState()
        val parsed = TxtParser.parse(plainText)
        _project.value = parsed
        audioEngine.generateWaveform("pasted_lyrics")
        triggerAutoSave()
    }

    fun loadDemoProject() {
        pushUndoState()
        val demo = DemoProjectProvider.createDemoProject()
        _project.value = demo
        audioEngine.generateWaveform(demo.metadata.title)
        triggerAutoSave()
    }

    // --- LRCLIB SEARCH ---

    fun searchLrclib(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _isSearching.value = true
            _searchError.value = null
            try {
                val results = LrclibClient.api.search(query)
                _searchResults.value = results
                if (results.isEmpty()) {
                    _searchError.value = "No matching songs found on LRCLIB."
                }
            } catch (e: Exception) {
                _searchError.value = "Network error: ${e.localizedMessage ?: "Could not connect to LRCLIB"}"
            } finally {
                _isSearching.value = false
            }
        }
    }

    fun importFromLrclib(track: LrclibTrack) {
        pushUndoState()
        val lyrics = track.syncedLyrics ?: track.plainLyrics ?: ""
        val parsed = if (!track.syncedLyrics.isNullOrBlank()) {
            LrcParser.parse(lyrics)
        } else {
            TxtParser.parse(lyrics)
        }
        val durMs = track.duration?.let { (it * 1000.0).toLong() } ?: parsed.metadata.durationMs
        _project.value = parsed.copy(
            metadata = parsed.metadata.copy(
                title = track.trackName,
                artist = track.artistName,
                album = track.albumName ?: "",
                durationMs = durMs
            )
        )
        audioEngine.generateWaveform(track.trackName)
        triggerAutoSave()
    }

    // --- TRANSLATION & PRONUNCIATION ---

    fun translateProject(targetLang: TargetLanguage) {
        val lines = _project.value.lines
        if (lines.isEmpty()) return
        viewModelScope.launch {
            _isTranslating.value = true
            _translationError.value = null
            val lineTexts = lines.map { it.plainText }

            GeminiTranslationService.translateLines(lineTexts, targetLang.name)
                .onSuccess { translations ->
                    pushUndoState()
                    val updatedLines = lines.mapIndexed { idx, line ->
                        line.copy(translation = translations.getOrNull(idx) ?: line.translation)
                    }
                    _project.value = _project.value.copy(lines = updatedLines)
                    triggerAutoSave()
                }
                .onFailure { err ->
                    _translationError.value = err.localizedMessage
                }
            _isTranslating.value = false
        }
    }

    fun autoGeneratePronunciations() {
        pushUndoState()
        val updatedLines = _project.value.lines.map { line ->
            val phon = PhoneticEngine.toPracticalPhonetics(line.plainText)
            line.copy(pronunciation = phon)
        }
        _project.value = _project.value.copy(lines = updatedLines)
        triggerAutoSave()
    }

    fun updateLineTranslation(lineId: String, translation: String) {
        val updatedLines = _project.value.lines.map { line ->
            if (line.id == lineId) line.copy(translation = translation) else line
        }
        _project.value = _project.value.copy(lines = updatedLines)
        triggerAutoSave()
    }

    fun updateLinePronunciation(lineId: String, pronunciation: String) {
        val updatedLines = _project.value.lines.map { line ->
            if (line.id == lineId) line.copy(pronunciation = pronunciation) else line
        }
        _project.value = _project.value.copy(lines = updatedLines)
        triggerAutoSave()
    }

    // --- PROJECT MANAGEMENT ---

    fun updateMetadata(title: String, artist: String, album: String) {
        _project.value = _project.value.copy(
            metadata = _project.value.metadata.copy(
                title = title,
                artist = artist,
                album = album
            )
        )
        triggerAutoSave()
    }

    fun createNewProject(title: String = "Untitled Song", artist: String = "Artist") {
        pushUndoState()
        _project.value = Project(
            metadata = SongMetadata(title = title, artist = artist),
            singers = Singer.defaultSingers(),
            lines = emptyList()
        )
        audioEngine.generateWaveform(title)
        triggerAutoSave()
    }

    fun loadProject(project: Project) {
        pushUndoState()
        _project.value = project
        audioEngine.generateWaveform(project.metadata.title)
    }

    fun duplicateProject(project: Project) {
        viewModelScope.launch {
            val dup = project.copy(
                id = UUID.randomUUID().toString(),
                metadata = project.metadata.copy(title = "${project.metadata.title} (Copy)"),
                updatedAt = System.currentTimeMillis()
            )
            repository.saveProject(dup)
        }
    }

    fun deleteProject(project: Project) {
        viewModelScope.launch {
            repository.deleteProject(project.id)
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
    }
}
