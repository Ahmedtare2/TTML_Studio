package com.example

import com.example.domain.model.LyricLine
import com.example.domain.model.LyricWord
import com.example.domain.model.Project
import com.example.domain.model.Singer
import com.example.domain.model.SongMetadata
import com.example.domain.model.TimeUtils
import com.example.domain.parsers.LrcParser
import com.example.domain.parsers.TxtParser
import com.example.domain.translate.ArabicTransliterationStyle
import com.example.domain.translate.PhoneticEngine
import com.example.domain.ttml.TtmlProfile
import com.example.domain.ttml.TtmlSerializer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TtmlStudioUnitTest {

    @Test
    fun testTimecodeFormatting() {
        assertEquals("00:00.000", TimeUtils.formatDisplayTime(0L))
        assertEquals("01:23.450", TimeUtils.formatDisplayTime(83450L))
        assertEquals("01:23", TimeUtils.formatShortTime(83450L))
        assertEquals("00:01:23.450", TimeUtils.formatTtmlTimestamp(83450L))
        assertEquals("[01:23.45]", TimeUtils.formatLrcTimestamp(83450L))
        assertEquals("00:01:23,450", TimeUtils.formatSrtTimestamp(83450L))
    }

    @Test
    fun testTtmlTimestampParsing() {
        assertEquals(83450L, TimeUtils.parseTtmlTimestamp("00:01:23.450"))
        assertEquals(83450L, TimeUtils.parseTtmlTimestamp("01:23.450"))
        assertEquals(83450L, TimeUtils.parseTtmlTimestamp("83.45s"))
        assertEquals(83450L, TimeUtils.parseTtmlTimestamp("83450ms"))
    }

    @Test
    fun testLrcTimestampParsing() {
        assertEquals(83450L, TimeUtils.parseLrcTimestamp("[01:23.45]"))
        assertEquals(83450L, TimeUtils.parseLrcTimestamp("<01:23.45>"))
    }

    @Test
    fun testTtmlSerialization() {
        val project = Project(
            metadata = SongMetadata(title = "Rock & Roll", artist = "The Band"),
            singers = listOf(Singer("v1", "Singer One", 0xFF8B5CF6)),
            lines = listOf(
                LyricLine(
                    singerId = "v1",
                    beginMs = 1000L,
                    endMs = 4000L,
                    words = listOf(
                        LyricWord(text = "Rock", beginMs = 1000L, endMs = 2000L),
                        LyricWord(text = "&", beginMs = 2050L, endMs = 2500L),
                        LyricWord(text = "Roll", beginMs = 2550L, endMs = 4000L)
                    )
                )
            )
        )

        val xml = TtmlSerializer.serialize(project, TtmlProfile.APPLE_MUSIC)

        assertTrue("Must declare TTML namespace", xml.contains("xmlns=\"http://www.w3.org/ns/ttml\""))
        assertTrue("Must declare iTunes namespace", xml.contains("xmlns:itunes=\"http://music.apple.com/lyric-ttml\""))
        assertTrue("Must escape ampersand in title", xml.contains("<ttm:title>Rock &amp; Roll</ttm:title>"))
        assertTrue("Must escape ampersand in word span", xml.contains("&amp;"))
        assertTrue("Must contain word spans with begin/end", xml.contains("begin=\"00:00:01.000\""))

        val report = TtmlSerializer.validate(project)
        assertTrue("Should be valid report", report.isValid)
        assertEquals(1, report.lineCount)
        assertEquals(3, report.wordCount)
    }

    @Test
    fun testLrcParser() {
        val lrc = """
            [ti:Test Track]
            [ar:Artist]
            [00:05.00]Hello world
            [00:10.00]Second line
        """.trimIndent()

        val project = LrcParser.parse(lrc)
        assertEquals("Test Track", project.metadata.title)
        assertEquals("Artist", project.metadata.artist)
        assertEquals(2, project.lines.size)
        assertEquals(5000L, project.lines[0].beginMs)
        assertEquals(10000L, project.lines[1].beginMs)
    }

    @Test
    fun testTxtParser() {
        val text = "First line here\nSecond line now"
        val project = TxtParser.parse(text)
        assertEquals(2, project.lines.size)
        assertEquals(3, project.lines[0].words.size)
        assertEquals(3, project.lines[1].words.size)
    }

    @Test
    fun testArabicTransliteration() {
        val arabicWord = "سلام"
        assertTrue("Should detect Arabic script", PhoneticEngine.isArabic(arabicWord))
        assertFalse("Should not detect English as Arabic", PhoneticEngine.isArabic("Hello"))

        val alaLc = PhoneticEngine.transliterateArabic(arabicWord, ArabicTransliterationStyle.ALA_LC)
        assertTrue("ALA-LC transliteration should not be empty", alaLc.isNotEmpty())

        val practical = PhoneticEngine.transliterateArabic("حب", ArabicTransliterationStyle.PRACTICAL)
        assertTrue("Practical transliteration of ha-baa should contain 7", practical.contains("7"))
    }
}
